@echo off
rem Rebuilds the game in this folder (keeps your gamertag, claim and account).
call "%~dp0INSTALL.cmd" -Rebuild
