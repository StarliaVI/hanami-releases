@echo off
rem War for Cybertron - Community Online Edition installer. Changes only files inside this folder
rem (plus winget tool installs you approve, and an optional desktop shortcut).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-WFC-Online.ps1" %*
pause
