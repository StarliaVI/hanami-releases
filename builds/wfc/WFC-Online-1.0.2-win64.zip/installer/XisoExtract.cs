// Xbox 360 / Xbox disc image (XDVDFS / "XISO") extractor.
// Reads the player's OWN game image and writes its files to a folder.
// Supports full disc images (XGD2/XGD3 game partition) and trimmed/rebuilt XISOs.
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class XisoExtract
{
    const int Sector = 2048;
    static readonly byte[] Magic = Encoding.ASCII.GetBytes("MICROSOFT*XBOX*MEDIA");
    // Game partition offsets: rebuilt XISO, XGD3, XGD2 (two variants), XGD1.
    static readonly long[] Offsets = { 0L, 0x2080000L, 0xFD90000L, 0xFDA0000L, 0x18300000L };

    public static long FindPartition(string iso)
    {
        using (var fs = new FileStream(iso, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
            var buf = new byte[20];
            foreach (var off in Offsets)
            {
                if (off + 32 * Sector + 20 > fs.Length) continue;
                fs.Position = off + 32 * Sector;
                if (fs.Read(buf, 0, 20) == 20 && Same(buf, Magic)) return off;
            }
        }
        return -1;
    }

    static bool Same(byte[] a, byte[] b)
    {
        for (int i = 0; i < b.Length; i++) if (a[i] != b[i]) return false;
        return true;
    }

    public delegate void Progress(long done, long total, string file);

    // Lists every file (relative path -> size) without extracting.
    public static List<KeyValuePair<string, long>> List(string iso)
    {
        var result = new List<KeyValuePair<string, long>>();
        Walk(iso, null, null, result);
        return result;
    }

    // Extracts all files to outDir. Returns total bytes written.
    public static long Extract(string iso, string outDir, Progress progress)
    {
        return Walk(iso, outDir, progress, null);
    }

    static long Walk(string iso, string outDir, Progress progress, List<KeyValuePair<string, long>> listing)
    {
        long part = FindPartition(iso);
        if (part < 0) throw new InvalidDataException("Not an Xbox 360 game disc image (no XDVDFS volume found).");
        using (var fs = new FileStream(iso, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 20))
        {
            var vd = new byte[Sector];
            fs.Position = part + 32 * Sector;
            ReadExact(fs, vd, Sector);
            uint rootSector = BitConverter.ToUInt32(vd, 20);
            uint rootSize = BitConverter.ToUInt32(vd, 24);
            // First pass: collect files (for totals / listing), guarding against loops.
            var files = new List<Entry>();
            var seen = new HashSet<long>();
            ReadDir(fs, part, rootSector, rootSize, "", files, seen, 0);
            long total = 0;
            foreach (var f in files) total += f.Size;
            if (listing != null)
            {
                foreach (var f in files) listing.Add(new KeyValuePair<string, long>(f.Path, f.Size));
                return total;
            }
            long done = 0;
            var copy = new byte[1 << 20];
            string root = Path.GetFullPath(outDir);
            foreach (var f in files)
            {
                string dest = Path.GetFullPath(Path.Combine(root, f.Path));
                if (!dest.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Unsafe path in image: " + f.Path);
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                if (progress != null) progress(done, total, f.Path);
                using (var o = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 20))
                {
                    fs.Position = part + (long)f.Sector * Sector;
                    long left = f.Size;
                    while (left > 0)
                    {
                        int n = fs.Read(copy, 0, (int)Math.Min(copy.Length, left));
                        if (n <= 0) throw new EndOfStreamException("Image ends inside " + f.Path + " (truncated download?)");
                        o.Write(copy, 0, n);
                        left -= n;
                        done += n;
                        if (progress != null && (done & 0x3FFFFFF) < n) progress(done, total, f.Path);
                    }
                }
            }
            if (progress != null) progress(total, total, "");
            return total;
        }
    }

    class Entry { public string Path; public uint Sector; public long Size; }

    static void ReadExact(Stream s, byte[] b, int n)
    {
        int got = 0;
        while (got < n) { int r = s.Read(b, got, n - got); if (r <= 0) throw new EndOfStreamException(); got += r; }
    }

    static void ReadDir(FileStream fs, long part, uint sector, uint size, string prefix, List<Entry> files,
                        HashSet<long> seen, int depth)
    {
        if (size == 0 || depth > 64) return;
        if (!seen.Add(sector)) return;
        if (size > 64 * 1024 * 1024) throw new InvalidDataException("Directory table too large");
        var dir = new byte[size];
        fs.Position = part + (long)sector * Sector;
        ReadExact(fs, dir, (int)size);
        var stack = new Stack<int>();
        var visited = new HashSet<int>();
        stack.Push(0);
        while (stack.Count > 0)
        {
            int off = stack.Pop();
            if (off < 0 || off + 14 > size || !visited.Add(off)) continue;
            ushort left = BitConverter.ToUInt16(dir, off);
            ushort right = BitConverter.ToUInt16(dir, off + 2);
            if (left == 0xFFFF && right == 0xFFFF) continue; // padding
            uint start = BitConverter.ToUInt32(dir, off + 4);
            uint len = BitConverter.ToUInt32(dir, off + 8);
            byte attr = dir[off + 12];
            int nameLen = dir[off + 13];
            if (off + 14 + nameLen > size) continue;
            string name = Encoding.ASCII.GetString(dir, off + 14, nameLen);
            if (left != 0) stack.Push(left * 4);
            if (right != 0) stack.Push(right * 4);
            if (nameLen == 0 || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name == "." || name == "..")
                continue;
            string path = prefix.Length == 0 ? name : prefix + "\\" + name;
            if ((attr & 0x10) != 0) ReadDir(fs, part, start, len, path, files, seen, depth + 1);
            else files.Add(new Entry { Path = path, Sector = start, Size = len });
        }
    }
}
