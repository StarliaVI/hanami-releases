// warforcybertron - ReXGlue Recompiled Project
//
// Customize your app by overriding virtual hooks from rex::ReXApp.

#pragma once

#include "wfc_fps_overlay.h"
#include <rex/rex_app.h>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <string>
#include <cwchar>
#include <filesystem>
#endif

class WarForCybertronApp : public rex::ReXApp {
 public:
  using rex::ReXApp::ReXApp;
  void OnCreateDialogs(rex::ui::ImGuiDrawer* drawer) override {
    drawer->AddDialog(new WfcFpsOverlay(drawer));
  }


  static std::unique_ptr<rex::ui::WindowedApp> Create(
      rex::ui::WindowedAppContext& ctx) {
    return std::unique_ptr<WarForCybertronApp>(new WarForCybertronApp(ctx, "warforcybertron",
        PPCImageConfig));
  }

  // Override virtual hooks for customization:
  // void OnPostInitLogging() override {}
  // void OnPreSetup(rex::RuntimeConfig& config) override {}
  // void OnLoadXexImage(std::string& xex_image) override {}
  // void OnPostLoadXexImage() override {}
  // void OnPostSetup() override {}
  // void OnCreateDialogs(rex::ui::ImGuiDrawer* drawer) override {}
  // std::unique_ptr<rex::ui::ImGuiDialog> CreateAchievementsOverlay() override;
  // std::unique_ptr<rex::ui::AchievementNotificationDialog>
  // CreateAchievementNotificationDialog() override;
  // void OnShutdown() override {}
  // WFC Online Edition: keep saves/profile in a folder next to the game
  // (FSR\UserData) so this install never shares or reads another install's
  // saves. An explicit --user_data_root on the command line still wins.
  void OnConfigurePaths(rex::PathConfig& paths) override {
#if defined(_WIN32)
    const wchar_t* cmd = GetCommandLineW();
    if (cmd && std::wcsstr(cmd, L"--user_data_root")) return;
    std::wstring exe(32768, L'\0');
    DWORD n = GetModuleFileNameW(nullptr, exe.data(), static_cast<DWORD>(exe.size()));
    if (n == 0 || n >= exe.size()) return;
    exe.resize(n);
    std::error_code ec;
    auto dir = std::filesystem::path(exe).parent_path() / L"UserData";
    std::filesystem::create_directories(dir, ec);
    if (!ec || std::filesystem::is_directory(dir, ec)) paths.user_data_root = dir;
#else
    (void)paths;
#endif
  }
};
