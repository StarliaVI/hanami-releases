// warforcybertron - ReXGlue Recompiled Project

#include "generated/default/warforcybertron_init.h"

#include "warforcybertron_app.h"

// WFC_DISCORD_NATIVE_BEGIN
#include "wfc_discord_presence.h"
static auto WfcCreateWithDiscordPresence(rex::ui::WindowedAppContext& ctx) {
  auto app = WarForCybertronApp::Create(ctx);
  if (app) wfc_discord::Start();
  return app;
}
REX_DEFINE_APP(warforcybertron, WfcCreateWithDiscordPresence)
// WFC_DISCORD_NATIVE_END

