#pragma once
// WFC Discord Rich Presence: native Discord IPC, no external launcher or DLL.
// Only included by the Windows ReXGlue game entry point.
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace wfc_discord {
namespace detail {
constexpr const char* kApplicationId = "1566617497052905613";
constexpr const char* kCredit = "Created By Myowcha";
constexpr std::uint32_t kMaxPayload = 256U * 1024U;

inline bool WriteAll(HANDLE pipe, const void* data, std::size_t size) {
  const auto* p = static_cast<const unsigned char*>(data);
  while (size > 0) {
    DWORD n = 0;
    const DWORD batch = static_cast<DWORD>(size);
    if (!WriteFile(pipe, p, batch, &n, nullptr) || n == 0) return false;
    p += n;
    size -= n;
  }
  return true;
}
inline bool ReadAll(HANDLE pipe, void* data, std::size_t size) {
  auto* p = static_cast<unsigned char*>(data);
  while (size > 0) {
    DWORD n = 0;
    const DWORD batch = static_cast<DWORD>(size);
    if (!ReadFile(pipe, p, batch, &n, nullptr) || n == 0) return false;
    p += n;
    size -= n;
  }
  return true;
}
inline bool Send(HANDLE pipe, std::uint32_t op, const std::string& payload) {
  if (payload.size() > kMaxPayload) return false;
  std::uint32_t size = static_cast<std::uint32_t>(payload.size());
  unsigned char header[8] = {};
  for (int i = 0; i < 4; ++i) {
    header[i] = static_cast<unsigned char>((op >> (i * 8)) & 0xff);
    header[4 + i] = static_cast<unsigned char>((size >> (i * 8)) & 0xff);
  }
  return WriteAll(pipe, header, sizeof header) &&
         WriteAll(pipe, payload.data(), payload.size());
}
inline bool Receive(HANDLE pipe, std::uint32_t& op, std::string& payload) {
  unsigned char header[8] = {};
  if (!ReadAll(pipe, header, sizeof header)) return false;
  op = 0;
  std::uint32_t size = 0;
  for (int i = 0; i < 4; ++i) {
    op |= std::uint32_t(header[i]) << (i * 8);
    size |= std::uint32_t(header[4 + i]) << (i * 8);
  }
  if (size > kMaxPayload) return false;
  payload.resize(size);
  return size == 0 || ReadAll(pipe, &payload[0], size);
}
inline HANDLE OpenDiscordPipe() {
  for (int i = 0; i < 10; ++i) {
    for (int style = 0; style < 2; ++style) {
      std::wstring path = (style == 0 ? L"\\\\?\\pipe\\discord-ipc-" :
                                        L"\\\\.\\pipe\\discord-ipc-");
      path += std::to_wstring(i);
      HANDLE pipe = CreateFileW(path.c_str(), GENERIC_READ | GENERIC_WRITE,
                                0, nullptr, OPEN_EXISTING, 0, nullptr);
      if (pipe != INVALID_HANDLE_VALUE) return pipe;
    }
  }
  return INVALID_HANDLE_VALUE;
}
inline bool WaitForReady(HANDLE pipe) {
  for (int i = 0; i < 5; ++i) {
    std::uint32_t op = 0;
    std::string payload;
    if (!Receive(pipe, op, payload)) return false;
    if (op == 3) {
      if (!Send(pipe, 4, payload)) return false; // Discord PING -> PONG
    } else if (op == 2) {
      return false;
    } else if (op == 1 && payload.find("\"READY\"") != std::string::npos) {
      return true;
    }
  }
  return false;
}
inline DWORD WINAPI Worker(LPVOID) {
  for (;;) {
    HANDLE pipe = OpenDiscordPipe();
    if (pipe == INVALID_HANDLE_VALUE) {
      Sleep(5000); // Discord not running; never block game startup
      continue;
    }
    const std::string handshake =
        std::string("{\"v\":1,\"client_id\":\"") + kApplicationId + "\"}";
    if (Send(pipe, 0, handshake) && WaitForReady(pipe)) {
      for (;;) {
        const std::string activity =
            std::string("{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":") +
            std::to_string(GetCurrentProcessId()) +
            ",\"activity\":{\"type\":0,\"details\":\"" + kCredit +
            "\"}},\"nonce\":\"wfc-" + std::to_string(GetTickCount64()) + "\"}";
        if (!Send(pipe, 1, activity)) break;
        std::uint32_t op = 0;
        std::string response;
        if (!Receive(pipe, op, response) || op == 2) break;
        if (op == 3 && !Send(pipe, 4, response)) break;
        if (op == 1 && response.find("\"ERROR\"") != std::string::npos) break;
        Sleep(20000); // Refresh and reconnect if Discord restarts
      }
    }
    CloseHandle(pipe);
    Sleep(5000);
  }
}
} // namespace detail
inline void Start() {
  static std::atomic<bool> launched{false};
  if (launched.exchange(true)) return;
  HANDLE worker = CreateThread(nullptr, 0, &detail::Worker, nullptr, 0, nullptr);
  if (worker != nullptr) {
    CloseHandle(worker); // Thread lives only as long as game process
  } else {
    launched.store(false);
  }
}
} // namespace wfc_discord
#else
namespace wfc_discord { inline void Start() {} }
#endif
