#pragma once

// War for Cybertron — in-game F2 host presentation FPS HUD.
// Larger top-left version.
#include <cstdio>
#include <rex/ui/imgui_dialog.h>
#include <rex/ui/keybinds.h>
#include <imgui.h>

class WfcFpsOverlay final : public rex::ui::ImGuiDialog {
 public:
  explicit WfcFpsOverlay(rex::ui::ImGuiDrawer* drawer)
      : rex::ui::ImGuiDialog(drawer) {
    rex::ui::RegisterBind(
        "bind_wfc_fps_hud", "F2", "Show/hide War for Cybertron FPS", [this]() {
          visible_ = !visible_;
        });
  }

  ~WfcFpsOverlay() override {
    rex::ui::UnregisterBind("bind_wfc_fps_hud");
  }

 protected:
  void OnDraw(ImGuiIO& io) override {
    if (!visible_) return;

    const float fps = io.Framerate;
    const float milliseconds = fps > 0.01f ? 1000.0f / fps : 0.0f;

    char line[96];
    std::snprintf(line, sizeof(line), "FPS  %.0f   %.1f ms", fps, milliseconds);

    // True top-left placement.
    const ImVec2 p(18.0f, 18.0f);

    // Bigger fonts.
    const float mainFontSize = 28.0f;
    const float subFontSize  = 19.0f;

    ImDrawList* dl = ImGui::GetForegroundDrawList();

    // Background panel.
    dl->AddRectFilled(
        ImVec2(p.x - 10.0f, p.y - 8.0f),
        ImVec2(p.x + 255.0f, p.y + 68.0f),
        IM_COL32(8, 10, 18, 215), 6.0f);

    // Accent bar on the left.
    dl->AddRectFilled(
        ImVec2(p.x - 10.0f, p.y - 8.0f),
        ImVec2(p.x - 5.0f,  p.y + 68.0f),
        IM_COL32(137, 72, 224, 255), 6.0f);

    const ImU32 color =
        fps >= 55.0f ? IM_COL32(113, 237, 195, 255) :
        fps >= 29.0f ? IM_COL32(255, 208, 100, 255) :
                       IM_COL32(255, 117, 112, 255);

    ImFont* font = ImGui::GetFont();

    // Shadow
    dl->AddText(font, mainFontSize, ImVec2(p.x + 1.5f, p.y + 1.5f),
                IM_COL32(0, 0, 0, 180), line);
    dl->AddText(font, subFontSize, ImVec2(p.x + 1.5f, p.y + 35.5f),
                IM_COL32(0, 0, 0, 180), "F2  |  DISPLAY FPS");

    // Main text
    dl->AddText(font, mainFontSize, p, color, line);
    dl->AddText(font, subFontSize, ImVec2(p.x, p.y + 34.0f),
                IM_COL32(205, 210, 220, 255), "F2  |  DISPLAY FPS");
  }

 private:
  bool visible_ = false;
};