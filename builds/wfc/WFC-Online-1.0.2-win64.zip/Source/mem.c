#include <stddef.h>
__attribute__((optnone)) void *memset(void *dest,int value,size_t n){unsigned char *p=(unsigned char*)dest;for(size_t i=0;i<n;i++)p[i]=(unsigned char)value;return dest;}
__attribute__((optnone)) void *memcpy(void *dest,const void *source,size_t n){unsigned char *p=(unsigned char*)dest;const unsigned char *s=(const unsigned char*)source;for(size_t i=0;i<n;i++)p[i]=s[i];return dest;}
