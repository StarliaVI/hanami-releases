/* War for Cybertron community launcher v1.0 FSR -- entirely native Win32 x64.
   No .NET, Windows PowerShell, VBS, web views or external runtime helper.
   Direct CreateProcessW, WinMM PCM WAV loop, transparent GDI panels, game window styling.
   The user-provided PNG/MP3 files are included as-is under Assets/. */
#include <stdint.h>
#include <stddef.h>

typedef void *PVOID, *HANDLE, *HWND, *HDC, *HGDIOBJ, *HBITMAP, *HBRUSH, *HFONT, *HINSTANCE, *HICON, *HCURSOR, *HMENU, *HMONITOR;
typedef const wchar_t *LPCWSTR;
typedef wchar_t *LPWSTR;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef int BOOL;
typedef long LONG;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef uintptr_t UINT_PTR, WPARAM;
typedef intptr_t LPARAM, LRESULT;
typedef unsigned long long ULONGLONG;
#define WINAPI __stdcall
#define DLL __declspec(dllimport)
#define TRUE 1
#define FALSE 0
#define NULLPTR ((void*)0)
#define WM_DESTROY 0x0002
#define WM_PAINT 0x000F
#define WM_CLOSE 0x0010
#define WM_TIMER 0x0113
#define WM_LBUTTONDOWN 0x0201
#define WM_LBUTTONUP 0x0202
#define WM_MOUSEMOVE 0x0200
#define WM_NCHITTEST 0x0084
#define WM_SETCURSOR 0x0020
#define WM_ERASEBKGND 0x0014
#define WM_KEYDOWN 0x0100
#define VK_ESCAPE 0x1B
#define VK_RETURN 0x0D
#define HTCLIENT 1
#define HTCAPTION 2
#define WS_POPUP 0x80000000u
#define WS_VISIBLE 0x10000000u
#define WS_OVERLAPPEDWINDOW 0x00CF0000u
#define WS_CAPTION 0x00C00000u
#define WS_THICKFRAME 0x00040000u
#define WS_SYSMENU 0x00080000u
#define WS_MINIMIZEBOX 0x00020000u
#define WS_MAXIMIZEBOX 0x00010000u
#define GWL_STYLE -16
#define CS_HREDRAW 0x0002u
#define CS_VREDRAW 0x0001u
#define CW_USEDEFAULT ((int)0x80000000)
#define SW_SHOW 5
#define SW_HIDE 0
#define SW_MINIMIZE 6
#define SM_CXSCREEN 0
#define SM_CYSCREEN 1
#define IMAGE_BITMAP 0
#define LR_LOADFROMFILE 0x10
#define LR_CREATEDIBSECTION 0x2000
#define MB_ICONERROR 0x10
#define MB_OK 0
#define MB_YESNO 4
#define IDYES 6
#define TRANSPARENT 1
#define DT_LEFT 0
#define DT_CENTER 1
#define DT_RIGHT 2
#define DT_VCENTER 4
#define DT_SINGLELINE 0x20
#define DT_END_ELLIPSIS 0x8000
#define SRCCOPY 0xCC0020
#define HALFTONE 4
#define SWP_NOSIZE 0x0001
#define SWP_NOMOVE 0x0002
#define SWP_NOZORDER 0x0004
#define SWP_NOACTIVATE 0x0010
#define SWP_FRAMECHANGED 0x0020
#define SWP_SHOWWINDOW 0x0040
#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define INVALID_FILE_ATTRIBUTES 0xFFFFFFFFu
#define OFN_EXPLORER 0x00080000u
#define OFN_FILEMUSTEXIST 0x1000u
#define OFN_PATHMUSTEXIST 0x800u
#define BIF_RETURNONLYFSDIRS 1u
#define BIF_NEWDIALOGSTYLE 0x40u
#define MONITOR_DEFAULTTONEAREST 2u
#define MCINOTIFY 0x3B9
#define MCI_NOTIFY_SUCCESSFUL 1
#define TIMER_MUSIC 11
#define TIMER_GAME 22
#define MAXPATH 32768
#define COLORREF(r,g,b) ((DWORD)((BYTE)(r) | ((DWORD)(BYTE)(g)<<8) | ((DWORD)(BYTE)(b)<<16)))

struct POINT {LONG x,y;};
struct RECT {LONG left,top,right,bottom;};
struct PAINTSTRUCT {HDC hdc; BOOL fErase;struct RECT rcPaint;BOOL fRestore;BOOL fIncUpdate;BYTE rgbReserved[32];};
struct MSG {HWND hwnd;UINT message;WPARAM wParam;LPARAM lParam;DWORD time;struct POINT pt;DWORD lPrivate;};
struct WNDCLASSEXW {UINT cbSize;UINT style;LRESULT (WINAPI *lpfnWndProc)(HWND,UINT,WPARAM,LPARAM);int cbClsExtra,cbWndExtra;HINSTANCE hInstance;HICON hIcon;HCURSOR hCursor;HBRUSH hbrBackground;LPCWSTR lpszMenuName,lpszClassName;HICON hIconSm;};
struct STARTUPINFOW {DWORD cb;LPWSTR lpReserved,lpDesktop,lpTitle;DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags;WORD wShowWindow,cbReserved2;BYTE *lpReserved2;HANDLE hStdInput,hStdOutput,hStdError;};
struct PROCESS_INFORMATION {HANDLE hProcess,hThread;DWORD dwProcessId,dwThreadId;};
struct OPENFILENAMEW {DWORD lStructSize;HWND hwndOwner;HINSTANCE hInstance;LPCWSTR lpstrFilter;LPWSTR lpstrCustomFilter;DWORD nMaxCustFilter,nFilterIndex;LPWSTR lpstrFile;DWORD nMaxFile;LPWSTR lpstrFileTitle;DWORD nMaxFileTitle;LPCWSTR lpstrInitialDir,lpstrTitle;DWORD Flags;WORD nFileOffset,nFileExtension;LPCWSTR lpstrDefExt;LPARAM lCustData;void *lpfnHook;LPCWSTR lpTemplateName;void *pvReserved;DWORD dwReserved,FlagsEx;};
struct BROWSEINFOW {HWND hwndOwner;void *pidlRoot;LPWSTR pszDisplayName;LPCWSTR lpszTitle;UINT ulFlags;void *lpfn;LPARAM lParam;int iImage;};
struct MONITORINFO {DWORD cbSize;struct RECT rcMonitor,rcWork;DWORD dwFlags;};

/* Windows functions: use OS-provided DLLs, with generated import .lib files. */
DLL DWORD WINAPI GetModuleFileNameW(HINSTANCE,LPWSTR,DWORD);
DLL DWORD WINAPI GetEnvironmentVariableW(LPCWSTR,LPWSTR,DWORD);
DLL DWORD WINAPI GetFileAttributesW(LPCWSTR);
DLL DWORD WINAPI GetPrivateProfileStringW(LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,DWORD,LPCWSTR);
DLL BOOL WINAPI WritePrivateProfileStringW(LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR);
DLL HINSTANCE WINAPI GetModuleHandleW(LPCWSTR);
DLL HINSTANCE WINAPI LoadLibraryW(LPCWSTR);
DLL void * WINAPI GetProcAddress(HINSTANCE,const char*);
DLL DWORD WINAPI GetLastError(void);
DLL BOOL WINAPI CreateProcessW(LPCWSTR,LPWSTR,void*,void*,BOOL,DWORD,void*,LPCWSTR,struct STARTUPINFOW*,struct PROCESS_INFORMATION*);
DLL DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
DLL BOOL WINAPI CloseHandle(HANDLE);
DLL void WINAPI ExitProcess(UINT);
DLL HGDIOBJ WINAPI SelectObject(HDC,HGDIOBJ);
DLL HGDIOBJ WINAPI GetStockObject(int);
DLL BOOL WINAPI DeleteObject(HGDIOBJ);
DLL HDC WINAPI CreateCompatibleDC(HDC);
DLL BOOL WINAPI DeleteDC(HDC);
DLL HBITMAP WINAPI CreateCompatibleBitmap(HDC,int,int);
DLL BOOL WINAPI BitBlt(HDC,int,int,int,int,HDC,int,int,DWORD);
DLL BOOL WINAPI StretchBlt(HDC,int,int,int,int,HDC,int,int,int,int,DWORD);
DLL int WINAPI SetStretchBltMode(HDC,int);
DLL HBRUSH WINAPI CreateSolidBrush(DWORD);
DLL int WINAPI FillRect(HDC,const struct RECT*,HBRUSH);
DLL int WINAPI SetBkMode(HDC,int);
DLL DWORD WINAPI SetTextColor(HDC,DWORD);
DLL HFONT WINAPI CreateFontW(int,int,int,int,int,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,LPCWSTR);
DLL BOOL WINAPI TextOutW(HDC,int,int,LPCWSTR,int);
DLL int WINAPI DrawTextW(HDC,LPCWSTR,int,struct RECT*,UINT);
DLL HWND WINAPI CreateWindowExW(DWORD,LPCWSTR,LPCWSTR,DWORD,int,int,int,int,HWND,HMENU,HINSTANCE,void*);
DLL BOOL WINAPI DestroyWindow(HWND);
DLL LRESULT WINAPI DefWindowProcW(HWND,UINT,WPARAM,LPARAM);
DLL unsigned short WINAPI RegisterClassExW(const struct WNDCLASSEXW*);
DLL BOOL WINAPI ShowWindow(HWND,int);
DLL BOOL WINAPI UpdateWindow(HWND);
DLL BOOL WINAPI GetMessageW(struct MSG*,HWND,UINT,UINT);
DLL BOOL WINAPI TranslateMessage(const struct MSG*);
DLL LRESULT WINAPI DispatchMessageW(const struct MSG*);
DLL HDC WINAPI BeginPaint(HWND,struct PAINTSTRUCT*);
DLL BOOL WINAPI EndPaint(HWND,const struct PAINTSTRUCT*);
DLL BOOL WINAPI GetClientRect(HWND,struct RECT*);
DLL BOOL WINAPI InvalidateRect(HWND,const struct RECT*,BOOL);
DLL UINT_PTR WINAPI SetTimer(HWND,UINT_PTR,UINT,void*);
DLL BOOL WINAPI KillTimer(HWND,UINT_PTR);
DLL int WINAPI GetSystemMetrics(int);
DLL BOOL WINAPI SetProcessDPIAware(void);
DLL HGDIOBJ WINAPI LoadImageW(HINSTANCE,LPCWSTR,UINT,int,int,UINT);
DLL int WINAPI MessageBoxW(HWND,LPCWSTR,LPCWSTR,UINT);
DLL BOOL WINAPI GetWindowRect(HWND,struct RECT*);
DLL BOOL WINAPI SetWindowPos(HWND,HWND,int,int,int,int,UINT);
DLL intptr_t WINAPI GetWindowLongPtrW(HWND,int);
DLL intptr_t WINAPI SetWindowLongPtrW(HWND,int,intptr_t);
DLL BOOL WINAPI EnumWindows(BOOL(WINAPI*)(HWND,LPARAM),LPARAM);
DLL DWORD WINAPI GetWindowThreadProcessId(HWND,DWORD*);
DLL BOOL WINAPI IsWindowVisible(HWND);
DLL BOOL WINAPI IsWindow(HWND);
DLL HMONITOR WINAPI MonitorFromWindow(HWND,DWORD);
DLL BOOL WINAPI GetMonitorInfoW(HMONITOR,struct MONITORINFO*);
DLL BOOL WINAPI AdjustWindowRectEx(struct RECT*,DWORD,BOOL,DWORD);
DLL HCURSOR WINAPI LoadCursorW(HINSTANCE,LPCWSTR);
DLL HICON WINAPI LoadIconW(HINSTANCE,LPCWSTR);
DLL HCURSOR WINAPI SetCursor(HCURSOR);
DLL BOOL WINAPI GetCursorPos(struct POINT*);
DLL BOOL WINAPI ScreenToClient(HWND,struct POINT*);
/* Resolve optional OS GDI alpha blending without an SDK msimg32.lib import. */
typedef BOOL (WINAPI *WFCAlphaBlendProc)(HDC,int,int,int,int,HDC,int,int,int,int,DWORD);
static BOOL WINAPI WFCAlphaBlend(HDC dst,int x,int y,int w,int h,HDC src,
                                  int sx,int sy,int sw,int sh,DWORD alpha){
    static WFCAlphaBlendProc proc=0;
    static BOOL attempted=FALSE;
    if(!attempted){
        attempted=TRUE;
        HINSTANCE module=LoadLibraryW(L"msimg32.dll");
        if(module)proc=(WFCAlphaBlendProc)GetProcAddress(module,"AlphaBlend");
    }
    if(!proc)return FALSE;
    return proc(dst,x,y,w,h,src,sx,sy,sw,sh,alpha);
}
DLL BOOL WINAPI GetOpenFileNameW(struct OPENFILENAMEW*);
DLL HMENU WINAPI CreatePopupMenu(void);
DLL BOOL WINAPI AppendMenuW(HMENU,UINT,UINT_PTR,LPCWSTR);
DLL UINT WINAPI TrackPopupMenu(HMENU,UINT,int,int,int,HWND,const struct RECT*);
DLL BOOL WINAPI DestroyMenu(HMENU);
DLL void WINAPI PostQuitMessage(int);
DLL void * WINAPI SHBrowseForFolderW(struct BROWSEINFOW*);
DLL BOOL WINAPI SHGetPathFromIDListW(void*,LPWSTR);
DLL void WINAPI CoTaskMemFree(void*);
/* Audio is decoded and attenuated during packaging, not on users' PCs. */

static HWND g_window;
static HINSTANCE g_instance;
static HBITMAP g_backBmp;
static HFONT g_fontSmall,g_fontMedium,g_fontLarge,g_fontTitle,g_fontPlay;
static wchar_t g_root[MAXPATH],g_assets[MAXPATH],g_image[MAXPATH],g_song[MAXPATH],g_settings[MAXPATH];
static wchar_t g_game[MAXPATH],g_data[MAXPATH],g_status[200],g_fsrGame[MAXPATH],g_fsrRuntime[MAXPATH],g_fsrXenos[MAXPATH],g_fsrDll[MAXPATH];
static int g_resolution=0,g_render=0,g_mode=0,g_sharp=0,g_sharpDragging=0,g_fsr=0,g_fsrOutput=1,g_settingsOpen=0,g_hover=0,g_screenW=1600,g_screenH=900;
static int g_gamePid=0,g_gameTick=0,g_gameWindowFound=0,g_exitMode=0;
static HANDLE g_gameProcess;
static HINSTANCE g_winmm;
typedef BOOL (WINAPI *PlaySoundFn)(LPCWSTR,HINSTANCE,DWORD);
static PlaySoundFn g_playSound;
static int g_musicOpen=0;
static int g_audioBackend=0; /* 0 = unavailable, 1 = Windows PCM WAV queued */
#define SND_ASYNC 0x0001u
#define SND_NODEFAULT 0x0002u
#define SND_LOOP 0x0008u
#define SND_FILENAME 0x00020000u
static const wchar_t *g_musicLabel[]={L"SOUNDTRACK UNAVAILABLE",L"SOUNDTRACK LOOPING AT 40%"};
/* Window size array retains v0.6 indices for INI backward compatibility. */
static const wchar_t *g_resolutions[]={L"Desktop (recommended)",L"1280 x 720",L"1600 x 900",L"1920 x 1080",L"2560 x 1440"};
static const int g_resW[]={0,1280,1600,1920,2560},g_resH[]={0,720,900,1080,1440};
static const wchar_t *g_modes[]={L"Borderless fullscreen",L"Windowed"};
static const wchar_t *g_fsrOutputs[]={L"720p to 1080p  |  Windowed",L"720p to 1440p  |  Recommended"};
static const int g_fsrOutW[]={1920,2560},g_fsrOutH[]={1080,1440};

/* This runtime is proven at 1x and 2x integer render scales.
   1080p exact 1.5x INTERNAL scaling isn't available in this branch.
   For 1080p output choose a 1920x1080 game window; 2x internal rendering
   is supersampled, NOT native 1080p render targets. */
static const wchar_t *g_renderNames[]={
    L"720p  |  Original (1x)",
    L"1080p  |  Supersampled (2x)",
    L"1440p  |  Sharp (2x)"
};
static const int g_renderScale[]={1,2,2};
static const wchar_t *g_renderDetails[]={
    L"720p: original 1280 x 720 internal render target (1x).",
    L"1080p output: 1440p internal, downsample to a 1080p window.",
    L"1440p: proven 2x Xenos internal rendering; 2560 x 1440."
};

static int wlen(const wchar_t *s){int i=0; if(!s)return 0;while(s[i] && i<MAXPATH-1)i++;return i;}
static void wcopy(wchar_t *dst,const wchar_t *src,int max){int i=0;if(!max)return;while(src&&src[i]&&i<max-1){dst[i]=src[i];i++;}dst[i]=0;}
static int weq(const wchar_t*a,const wchar_t*b){int i=0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==b[i];}
static void wcat(wchar_t *dst,const wchar_t *s,int max){int n=wlen(dst),i=0;while(s&&s[i]&&n<max-1)dst[n++]=s[i++];dst[n]=0;}
static int fileok(const wchar_t *p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
static int dirok(const wchar_t *p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES && (a&FILE_ATTRIBUTE_DIRECTORY);}
static void parentdir(wchar_t *p){int n=wlen(p);while(n>0 && p[n-1]!=L'\\' && p[n-1]!=L'/')n--;if(n>0)p[n-1]=0;}
static void wappendnum(wchar_t *to,unsigned v,int max);
static void savestate(){wchar_t buf[24];buf[0]=L'0'+g_resolution;buf[1]=0;WritePrivateProfileStringW(L"Launcher",L"Resolution",buf,g_settings);buf[0]=L'0'+g_mode;WritePrivateProfileStringW(L"Launcher",L"Mode",buf,g_settings);buf[0]=L'0'+g_render;WritePrivateProfileStringW(L"Launcher",L"RenderPreset",buf,g_settings);buf[0]=0;wappendnum(buf,(unsigned)g_sharp,24);WritePrivateProfileStringW(L"Launcher",L"CasSharpening",buf,g_settings);buf[0]=L'0'+g_fsr;WritePrivateProfileStringW(L"Launcher",L"FsrEnabled",buf,g_settings);buf[0]=L'0'+g_fsrOutput;WritePrivateProfileStringW(L"Launcher",L"FsrOutput",buf,g_settings);WritePrivateProfileStringW(L"Launcher",L"GameExe",g_game,g_settings);WritePrivateProfileStringW(L"Launcher",L"GameData",g_data,g_settings);}
static int validpaths(){return fileok(g_game)&&dirok(g_data);}
static int fsrready(){return fileok(g_fsrGame)&&fileok(g_fsrRuntime)&&fileok(g_fsrXenos)&&fileok(g_fsrDll);}
static void wappendnum(wchar_t *to,unsigned v,int max){
  wchar_t buf[16];int n=0;do{buf[n++]=(wchar_t)(L'0'+(v%10));v/=10;}while(v&&n<15);
  while(n>0){wchar_t c[2]={buf[--n],0};wcat(to,c,max);}
}
static void selectFsrOutput(int i){
    g_fsrOutput=i;
    /* Fixed 1080p output on a 1440p monitor must be windowed to remain 1080p. */
    if(g_fsr&& (g_fsrOutW[i]!=g_screenW || g_fsrOutH[i]!=g_screenH))g_mode=1;
}

static void initpaths(){
  GetModuleFileNameW(0,g_root,MAXPATH);parentdir(g_root);wcopy(g_assets,g_root,MAXPATH);wcat(g_assets,L"\\Assets",MAXPATH);
  wcopy(g_image,g_assets,MAXPATH);wcat(g_image,L"\\wfc_artwork.bmp",MAXPATH);
  wcopy(g_song,g_assets,MAXPATH);wcat(g_song,L"\\wfc_theme_40pct.wav",MAXPATH);
  wcopy(g_settings,g_root,MAXPATH);wcat(g_settings,L"\\settings.ini",MAXPATH);
  wcopy(g_fsrGame,g_root,MAXPATH);wcat(g_fsrGame,L"\\FSR\\warforcybertron.exe",MAXPATH);
  wcopy(g_fsrRuntime,g_root,MAXPATH);wcat(g_fsrRuntime,L"\\FSR\\rexruntime.dll",MAXPATH);
  wcopy(g_fsrXenos,g_root,MAXPATH);wcat(g_fsrXenos,L"\\FSR\\rexgpu-xenos.dll",MAXPATH);
  wcopy(g_fsrDll,g_root,MAXPATH);wcat(g_fsrDll,L"\\FSR\\amd_fidelityfx_dx12.dll",MAXPATH);
  wchar_t home[MAXPATH],fallback[MAXPATH];home[0]=0;GetEnvironmentVariableW(L"USERPROFILE",home,MAXPATH);
  wcopy(fallback,L"D:\\Recomp\\WarForCybertron-Recomp\\war_for_cybertron\\out\\build\\win-amd64-release\\warforcybertron.exe",MAXPATH);
  if(!fileok(fallback)){wcopy(fallback,home,MAXPATH);wcat(fallback,L"\\Projects\\WarForCybertron-Recomp\\war_for_cybertron\\out\\build\\win-amd64-release\\warforcybertron.exe",MAXPATH);}
  GetPrivateProfileStringW(L"Launcher",L"GameExe",fallback,g_game,MAXPATH,g_settings);
  wcopy(fallback,L"D:\\Recomp\\WarForCybertron-Recomp\\extracted_game",MAXPATH);
  if(!dirok(fallback)){wcopy(fallback,home,MAXPATH);wcat(fallback,L"\\Projects\\WarForCybertron-Recomp\\extracted_game",MAXPATH);}
  GetPrivateProfileStringW(L"Launcher",L"GameData",fallback,g_data,MAXPATH,g_settings);
  wchar_t n[16];GetPrivateProfileStringW(L"Launcher",L"Resolution",L"0",n,16,g_settings);g_resolution=(n[0]>=L'0'&&n[0]<=L'4')?n[0]-L'0':4; /* old 4K window clamps to 1440p */
  GetPrivateProfileStringW(L"Launcher",L"Mode",L"0",n,16,g_settings);g_mode=n[0]==L'1'?1:0;
  GetPrivateProfileStringW(L"Launcher",L"RenderPreset",L"0",n,16,g_settings);g_render=(n[0]>=L'0'&&n[0]<=L'2')?n[0]-L'0':2; /* legacy 4K+ prefs clamp to 1440p */
  GetPrivateProfileStringW(L"Launcher",L"CasSharpening",L"0",n,16,g_settings);
  g_sharp=0;for(int i=0;n[i]>=L'0'&&n[i]<=L'9'&&i<4;i++){g_sharp=g_sharp*10+(n[i]-L'0');if(g_sharp>100){g_sharp=100;break;}}
  GetPrivateProfileStringW(L"Launcher",L"FsrEnabled",L"0",n,16,g_settings);g_fsr=n[0]==L'1';
  GetPrivateProfileStringW(L"Launcher",L"FsrOutput",L"1",n,16,g_settings);g_fsrOutput=n[0]==L'0'?0:1;
  if(!fileok(g_game)){
    wcopy(fallback,g_root,MAXPATH);wcat(fallback,L"\\Game\\warforcybertron.exe",MAXPATH);
    if(fileok(fallback))wcopy(g_game,fallback,MAXPATH);
  }
  if(!dirok(g_data)){
    wcopy(fallback,g_root,MAXPATH);wcat(fallback,L"\\GameData",MAXPATH);
    if(dirok(fallback))wcopy(g_data,fallback,MAXPATH);
  }
  wcopy(g_status,validpaths()?L"READY TO PLAY":L"SELECT GAME FILES IN SETTINGS TO BEGIN",200);
}
/* Windows WinMM PlaySoundW plays uncompressed WAV without codecs or COM.
   The packaged WAV contains the original supplied soundtrack decoded to
   stereo PCM and attenuated to EXACTLY 40% linear amplitude ahead of time.
   SND_ASYNC|SND_LOOP makes Windows repeat it as long as this launcher runs.
   Stopping is explicit when PLAY succeeds or the launcher is closed.
   Never change system-wide/master volume, and never spawn other apps. */
static void stopmusic(void){
    if(g_playSound && g_musicOpen){
        g_playSound(0,0,0); /* explicitly stop the currently playing WAV */
        g_musicOpen=0;
    }
    g_audioBackend=0;
}
static void startmusic(void){
    g_audioBackend=0;
    if(!fileok(g_song))return;
    g_winmm=LoadLibraryW(L"winmm.dll");
    if(!g_winmm)return;
    g_playSound=(PlaySoundFn)GetProcAddress(g_winmm,"PlaySoundW");
    if(!g_playSound)return;
    if(g_playSound(g_song,0,SND_FILENAME|SND_NODEFAULT|SND_ASYNC|SND_LOOP)){
        g_musicOpen=1;
        g_audioBackend=1;
    }
    InvalidateRect(g_window,0,FALSE);
}
static void musicTick(void){/* OS handles WAV looping; no timer necessary. */}
static void fill(HDC dc,int x,int y,int w,int h,DWORD color){struct RECT r={x,y,x+w,y+h};HBRUSH brush=CreateSolidBrush(color);FillRect(dc,&r,brush);DeleteObject(brush);}
static void glass(HDC dc,int x,int y,int w,int h,int opacity,DWORD color){
  if(w<=0||h<=0)return;
  HDC tmp=CreateCompatibleDC(dc);HBITMAP bmp=CreateCompatibleBitmap(dc,1,1);HGDIOBJ old=SelectObject(tmp,bmp);
  fill(tmp,0,0,1,1,color);
  if(!WFCAlphaBlend(dc,x,y,w,h,tmp,0,0,1,1,((DWORD)(opacity&255)<<16)))fill(dc,x,y,w,h,color);
  SelectObject(tmp,old);DeleteObject(bmp);DeleteDC(tmp);
}
static void line(HDC dc,int x,int y,int w,int h,DWORD color){fill(dc,x,y,w,h,color);}
static void text(HDC dc,HFONT font,const wchar_t*s,int x,int y,int w,int h,DWORD color,UINT flags){
  struct RECT r={x,y,x+w,y+h};SelectObject(dc,font);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color);DrawTextW(dc,s,-1,&r,flags|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
}
static void chip(HDC dc,int x,int y,int w,int h,int hovered){
  glass(dc,x,y,w,h,hovered?174:112,COLORREF(7,15,24));
  line(dc,x,y+h-1,w,1,COLORREF(100,102,112));
}
static void separator(HDC dc,int x,int y,int w){
    glass(dc,x,y,w,1,125,COLORREF(183,148,138));
}
static void button(HDC dc,int x,int y,int w,int h,const wchar_t *label,int hovered,int isPlay){
    if(isPlay){
        glass(dc,x-4,y-4,w+8,h+8,100,COLORREF(47,4,8));
        fill(dc,x,y,w,h,hovered?COLORREF(255,102,64):COLORREF(211,55,37));
        line(dc,x,y,w,2,COLORREF(255,166,113));
        line(dc,x,y+h-2,w,2,COLORREF(139,37,33));
        text(dc,g_fontPlay,label,x+8,y,w-16,h,COLORREF(255,253,248),DT_CENTER);
    }else{
        glass(dc,x,y,w,h,hovered?190:155,COLORREF(15,11,19));
        line(dc,x,y,w,1,COLORREF(106,68,62));
        line(dc,x,y+h-1,w,1,COLORREF(106,68,62));
        text(dc,g_fontSmall,label,x+5,y,w-10,h,COLORREF(249,241,238),DT_CENTER);
    }
}
static void render(HDC dc){
    /* RB2-inspired composition, but native to the supplied Cybertron artwork. */
    if(g_backBmp){
      HDC src=CreateCompatibleDC(dc);HGDIOBJ old=SelectObject(src,g_backBmp);
      BitBlt(dc,0,0,1600,900,src,0,0,SRCCOPY);SelectObject(src,old);DeleteDC(src);
    }else fill(dc,0,0,1600,900,COLORREF(9,9,14));
    /* Cinematic darkening to echo the original Raging Blast 2 launcher. */
    glass(dc,0,0,1600,900,65,COLORREF(5,4,12));
    glass(dc,0,0,1010,900,55,COLORREF(8,5,12));
    glass(dc,0,0,570,900,36,COLORREF(7,6,12));

    /* Custom thin window bar -- the launcher is centered and NOT fullscreen. */
    glass(dc,0,0,1600,29,230,COLORREF(7,5,11));
    text(dc,g_fontSmall,L"TRANSFORMERS: WAR FOR CYBERTRON  ·  PC LAUNCHER",17,0,560,27,COLORREF(233,216,211),DT_LEFT);
    if(g_hover==1)glass(dc,1493,0,43,29,90,COLORREF(111,69,57));
    if(g_hover==2)glass(dc,1547,0,48,29,155,COLORREF(155,24,27));
    text(dc,g_fontSmall,L"—",1497,0,36,28,COLORREF(250,242,239),DT_CENTER);
    text(dc,g_fontSmall,L"×",1554,0,30,28,COLORREF(250,242,239),DT_CENTER);

    /* The source logo is already part of the precomposed background. */
    text(dc,g_fontSmall,L"MADE FOR THE",687,72,300,28,COLORREF(255,227,207),DT_CENTER);
    text(dc,g_fontMedium,L"WAR FOR CYBERTRON COMMUNITY",643,101,380,40,COLORREF(255,242,229),DT_CENTER);
    if(g_hover==11)glass(dc,1249,50,139,43,146,COLORREF(29,16,20));
    text(dc,g_fontSmall,L"SETTINGS",1252,50,130,42,COLORREF(251,241,234),DT_CENTER);
    if(g_hover==3)glass(dc,1417,50,136,43,146,COLORREF(29,16,20));
    text(dc,g_fontSmall,L"ABOUT",1424,50,120,42,COLORREF(251,241,234),DT_CENTER);

    /* Same native RB2-inspired glass panel, now with first-class FSR settings. */
    glass(dc,95,175,863,572,201,COLORREF(13,7,17));
    line(dc,95,175,863,1,COLORREF(92,58,62));
    line(dc,95,746,863,1,COLORREF(93,56,62));
    line(dc,95,175,1,572,COLORREF(92,58,62));
    line(dc,957,175,1,572,COLORREF(92,58,62));
    fill(dc,125,203,4,34,COLORREF(242,103,67));

    if(!g_settingsOpen){
      text(dc,g_fontTitle,L"GRAPHICS SETTINGS",145,194,660,42,COLORREF(253,248,245),DT_LEFT);
      text(dc,g_fontSmall,L"Display and FidelityFX upscaling",145,242,620,27,COLORREF(186,172,172),DT_LEFT);
      separator(dc,176,282,741);

      /* FSR switch: a meaningful control, not a decorative toggle. */
      text(dc,g_fontMedium,L"AMD FidelityFX FSR",175,288,440,35,COLORREF(250,243,237),DT_LEFT);
      text(dc,g_fontSmall,L"Spatial upscaling  |  sharpen output",175,320,430,22,COLORREF(187,177,183),DT_LEFT);
      glass(dc,787,293,141,43,190,g_fsr?COLORREF(14,64,80):COLORREF(39,31,40));
      line(dc,787,293,141,1,g_fsr?COLORREF(63,221,236):COLORREF(127,109,111));
      fill(dc,g_fsr?891:791,299,31,31,g_fsr?COLORREF(93,234,239):COLORREF(114,107,118));
      text(dc,g_fontSmall,g_fsr?L"ON":L"OFF",g_fsr?799:829,296,66,37,g_fsr?COLORREF(167,251,246):COLORREF(209,198,203),DT_CENTER);
      separator(dc,176,351,741);

      text(dc,g_fontMedium,L"Upscale target",175,355,430,36,g_fsr?COLORREF(245,238,235):COLORREF(132,125,132),DT_LEFT);
      text(dc,g_fontSmall,L"Internal 720p  /  output resolution",175,386,424,21,COLORREF(170,160,170),DT_LEFT);
      chip(dc,626,357,302,44,g_fsr&&g_hover==15);
      if(!g_fsr)glass(dc,626,357,302,44,143,COLORREF(11,10,16));
      text(dc,g_fontSmall,g_fsrOutputs[g_fsrOutput],637,360,270,38,g_fsr?COLORREF(238,246,247):COLORREF(142,136,143),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"⌄":L"·",899,360,21,38,g_fsr?COLORREF(240,229,223):COLORREF(132,120,132),DT_CENTER);
      separator(dc,176,422,741);

      text(dc,g_fontMedium,L"Native render resolution",175,428,440,36,g_fsr?COLORREF(143,136,143):COLORREF(245,238,235),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"Controlled by FSR while enabled":L"Maximum native render: 1440p",175,459,430,21,COLORREF(171,160,171),DT_LEFT);
      chip(dc,626,430,302,44,!g_fsr&&g_hover==12);
      if(g_fsr)glass(dc,626,430,302,44,159,COLORREF(11,10,16));
      text(dc,g_fontSmall,g_fsr?L"720p  |  FSR managed":g_renderNames[g_render],640,432,260,38,g_fsr?COLORREF(148,143,153):COLORREF(250,241,238),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"·":L"⌄",899,432,21,38,COLORREF(166,149,155),DT_CENTER);
      separator(dc,176,495,741);

      text(dc,g_fontMedium,L"Game window size",175,499,435,36,g_fsr?COLORREF(143,136,143):COLORREF(245,238,235),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"Follows FSR output target":L"Desktop is recommended",175,529,420,22,COLORREF(171,160,171),DT_LEFT);
      chip(dc,626,501,302,44,!g_fsr&&g_hover==4);
      if(g_fsr)glass(dc,626,501,302,44,159,COLORREF(11,10,16));
      text(dc,g_fontSmall,g_fsr?L"FSR controlled":g_resolutions[g_resolution],640,503,264,38,g_fsr?COLORREF(148,143,153):COLORREF(250,241,238),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"·":L"⌄",899,503,21,38,COLORREF(166,149,155),DT_CENTER);
      separator(dc,176,568,741);

      text(dc,g_fontMedium,L"Display mode",175,573,435,36,COLORREF(245,238,235),DT_LEFT);
      text(dc,g_fontSmall,L"Borderless or windowed",175,605,390,20,COLORREF(171,160,171),DT_LEFT);
      chip(dc,626,574,302,44,g_hover==5);
      text(dc,g_fontSmall,g_modes[g_mode],640,577,260,38,COLORREF(250,241,238),DT_LEFT);
      text(dc,g_fontSmall,L"⌄",899,577,21,38,COLORREF(251,231,220),DT_CENTER);
      separator(dc,176,633,741);

      text(dc,g_fontMedium,L"AMD FidelityFX CAS Sharpening",175,636,450,36,COLORREF(245,238,235),DT_LEFT);
      text(dc,g_fontSmall,g_fsr?L"FSR + CAS post-pass (0% = default FSR)":L"Native CAS (0% = no CAS)",175,666,450,22,COLORREF(187,177,183),DT_LEFT);
      chip(dc,626,638,302,43,g_hover==13||g_sharpDragging);
      fill(dc,644,655,250,5,COLORREF(72,59,77));
      if(g_sharp>0)fill(dc,644,655,(250*g_sharp)/100,5,COLORREF(91,211,222));
      glass(dc,637+(250*g_sharp)/100,646,16,22,240,COLORREF(99,231,240));
      wchar_t casLabel[24];casLabel[0]=0;wappendnum(casLabel,(unsigned)g_sharp,24);wcat(casLabel,L"%",24);
      text(dc,g_fontSmall,casLabel,831,641,68,35,COLORREF(250,241,238),DT_RIGHT);
      separator(dc,176,697,741);
      text(dc,g_fontSmall,g_fsr?L"FSR uses original 720p rendering; native scaling is locked off.":L"Native upscaling is disabled. Select FSR above to enable it.",175,701,733,27,COLORREF(225,204,195),DT_LEFT);
    }else{
      text(dc,g_fontTitle,L"GAME LOCATION",145,194,650,42,COLORREF(253,248,245),DT_LEFT);
      text(dc,g_fontSmall,L"Only needed if the game cannot be found automatically",145,242,740,28,COLORREF(186,172,172),DT_LEFT);
      separator(dc,176,296,741);
      text(dc,g_fontMedium,L"Game executable",175,312,350,48,COLORREF(252,242,236),DT_LEFT);
      chip(dc,175,358,754,45,g_hover==6);
      text(dc,g_fontSmall,g_game,188,360,615,41,COLORREF(248,239,230),DT_LEFT);
      text(dc,g_fontSmall,L"BROWSE",820,360,98,41,COLORREF(252,237,225),DT_CENTER);
      separator(dc,176,428,741);
      text(dc,g_fontMedium,L"Game data folder",175,440,350,45,COLORREF(252,242,236),DT_LEFT);
      chip(dc,175,484,754,45,g_hover==7);
      text(dc,g_fontSmall,g_data,188,486,615,41,COLORREF(248,239,230),DT_LEFT);
      text(dc,g_fontSmall,L"BROWSE",820,486,98,41,COLORREF(252,237,225),DT_CENTER);
      text(dc,g_fontSmall,L"Click SETTINGS to return to the main screen.",175,565,650,45,COLORREF(230,208,197),DT_LEFT);
    }
    /* FidelityFX CAS settings; no misleading frame-generation placeholder. */
    glass(dc,1015,376,499,229,181,COLORREF(9,8,18));
    line(dc,1015,376,499,1,COLORREF(101,70,78));
    fill(dc,1038,400,4,23,g_fsr?COLORREF(70,225,239):COLORREF(126,109,119));
    text(dc,g_fontMedium,L"FIDELITYFX IMAGE QUALITY",1055,388,420,45,COLORREF(251,242,238),DT_LEFT);
    text(dc,g_fontSmall,g_fsr?(fsrready()?L"FSR READY  /  XENOS DX12":L"FSR RUNTIME NEEDS STAGING"):L"NATIVE PRESENTATION",1039,435,448,29,g_fsr?(fsrready()?COLORREF(128,246,215):COLORREF(254,190,144)):COLORREF(186,174,187),DT_LEFT);
    separator(dc,1038,476,450);
    text(dc,g_fontMedium,L"CONTRAST ADAPTIVE SHARPENING",1039,486,442,35,COLORREF(238,229,238),DT_LEFT);
    text(dc,g_fontSmall,g_fsr?L"FSR upscale with optional CAS post-pass":L"Native CAS sharpening, no frame cap override",1039,530,448,28,COLORREF(185,206,204),DT_LEFT);
    text(dc,g_fontSmall,L"Set the strength in Graphics Settings.",1039,565,448,24,COLORREF(172,160,174),DT_LEFT);
    /* Small companion status card below the available artwork, like RB2. */
    glass(dc,1015,637,499,92,175,COLORREF(15,8,18));
    line(dc,1015,637,499,1,COLORREF(89,57,62));
    text(dc,g_fontMedium,validpaths()?L"READY TO PLAY":L"GAME NOT FOUND",1042,647,442,41,validpaths()?COLORREF(167,250,187):COLORREF(255,200,167),DT_LEFT);
    text(dc,g_fontSmall,validpaths()?L"Your next battle starts with PLAY.":L"Choose game files under SETTINGS.",1042,682,442,25,COLORREF(225,212,204),DT_LEFT);
    text(dc,g_fontSmall,g_musicLabel[g_audioBackend],1042,704,440,20,g_audioBackend?COLORREF(187,232,209):COLORREF(251,196,170),DT_LEFT);

    /* Bottom controls: same proportions and rhythm as the RB2 launcher. */
    button(dc,95,784,151,61,L"RESET",g_hover==9,0);
    button(dc,260,784,151,61,L"SAVE",g_hover==10,0);
    button(dc,439,777,307,76,L"▷   PLAY",g_hover==8,1);
    text(dc,g_fontSmall,L"WAR FOR CYBERTRON  ·  COMMUNITY LAUNCHER CAS v1.1",1123,852,401,30,COLORREF(248,242,232),DT_RIGHT);
}
static void paint(HWND window){struct PAINTSTRUCT p;HDC target=BeginPaint(window,&p);if(!target)return;
    struct RECT r;GetClientRect(window,&r);int width=r.right-r.left,height=r.bottom-r.top;
    if(width<1||height<1){EndPaint(window,&p);return;}
    HDC dc=CreateCompatibleDC(target);HBITMAP bmp=CreateCompatibleBitmap(target,1600,900);HGDIOBJ old=SelectObject(dc,bmp);
    render(dc);SetStretchBltMode(target,HALFTONE);
    StretchBlt(target,0,0,width,height,dc,0,0,1600,900,SRCCOPY);
    SelectObject(dc,old);DeleteObject(bmp);DeleteDC(dc);EndPaint(window,&p);
}
static int which(int x,int y){
    if(x>=1486&&x<1541&&y>=0&&y<30)return 1;
    if(x>=1542&&x<1600&&y>=0&&y<30)return 2;
    if(x>=1250&&x<1395&&y>=42&&y<100)return 11;
    if(x>=1410&&x<1556&&y>=42&&y<100)return 3;
    if(!g_settingsOpen&&x>=787&&x<=928&&y>=293&&y<=336)return 14;
    if(!g_settingsOpen&&g_fsr&&x>=626&&x<=928&&y>=357&&y<=401)return 15;
    if(!g_settingsOpen&&!g_fsr&&x>=626&&x<=928&&y>=430&&y<=474)return 12;
    if(!g_settingsOpen&&!g_fsr&&x>=626&&x<=928&&y>=501&&y<=545)return 4;
    if(!g_settingsOpen&&x>=626&&x<=928&&y>=574&&y<=618)return 5;
    if(!g_settingsOpen&&x>=626&&x<=928&&y>=638&&y<=681)return 13;
    if(g_settingsOpen&&x>=175&&x<=929&&y>=358&&y<=403)return 6;
    if(g_settingsOpen&&x>=175&&x<=929&&y>=484&&y<=529)return 7;
    if(x>=439&&x<=746&&y>=777&&y<=853)return 8;
    if(x>=95&&x<=246&&y>=784&&y<=845)return 9;
    if(x>=260&&x<=411&&y>=784&&y<=845)return 10;
    return 0;
}
static void updateCasFromMouse(LPARAM l){
    struct RECT r;GetClientRect(g_window,&r);
    int w=r.right-r.left;if(w<=0)return;
    int mouseX=(short)(l&0xFFFF);
    int x=mouseX*1600/w;
    int value=(x-644)*100/250;
    if(value<0)value=0;if(value>100)value=100;
    if(g_sharp!=value){g_sharp=value;InvalidateRect(g_window,0,FALSE);}
}
static int posHit(LPARAM l){int x=(short)(l&0xFFFF),y=(short)((l>>16)&0xFFFF);
    struct RECT r;GetClientRect(g_window,&r);int w=r.right-r.left,h=r.bottom-r.top;
    if(w<=0||h<=0)return 0;
    return which(x*1600/w,y*900/h);
}
static void choosemenu(HWND window,int menuId){
    HMENU menu=CreatePopupMenu();if(!menu)return;
    int count=menuId==4?5:menuId==12?3:2;
    for(int i=0;i<count;i++)AppendMenuW(menu,0,(UINT_PTR)(100+i),menuId==4?g_resolutions[i]:menuId==12?g_renderNames[i]:menuId==15?g_fsrOutputs[i]:g_modes[i]);
    struct POINT p;GetCursorPos(&p);
    UINT result=TrackPopupMenu(menu,0x100u|0x0004u,p.x,p.y,0,window,0);
    if(result>=100&&result<(UINT)(100+count)){
        if(menuId==4)g_resolution=(int)result-100;
        if(menuId==12)g_render=(int)result-100;
        if(menuId==5){
            g_mode=(int)result-100;
            /* Prevent the 1080p FSR preset from being silently stretched to 1440p. */
            if(g_fsr&&g_mode==0 &&
               (g_fsrOutW[g_fsrOutput]!=g_screenW||g_fsrOutH[g_fsrOutput]!=g_screenH)){
                g_fsrOutput=1;
                if(g_screenW!=2560||g_screenH!=1440)g_mode=1;
            }
        }
        if(menuId==15)selectFsrOutput((int)result-100);
        savestate();InvalidateRect(window,0,FALSE);
    }
    DestroyMenu(menu);
}
static void pickGame(void){
    wchar_t path[MAXPATH];wcopy(path,fileok(g_game)?g_game:L"",MAXPATH);
    const wchar_t filter[]=L"War for Cybertron (warforcybertron.exe)\0warforcybertron.exe\0Programs (*.exe)\0*.exe\0\0";
    struct OPENFILENAMEW f={0};f.lStructSize=sizeof(f);f.hwndOwner=g_window;
    f.lpstrFilter=filter;f.lpstrFile=path;f.nMaxFile=MAXPATH;
    f.lpstrTitle=L"Find your War for Cybertron game";f.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
    if(GetOpenFileNameW(&f)){wcopy(g_game,path,MAXPATH);savestate();}
    wcopy(g_status,validpaths()?L"READY TO PLAY":L"SELECT GAME FILES IN SETTINGS TO BEGIN",200);
    InvalidateRect(g_window,0,FALSE);
}
static void pickData(void){
    wchar_t display[300]={0};
    struct BROWSEINFOW b={0};b.hwndOwner=g_window;b.pszDisplayName=display;
    b.lpszTitle=L"Select the folder containing your extracted Xbox 360 game data";
    b.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;
    void *pidl=SHBrowseForFolderW(&b);
    if(pidl){wchar_t selected[MAXPATH];selected[0]=0;
        if(SHGetPathFromIDListW(pidl,selected)){wcopy(g_data,selected,MAXPATH);savestate();}
        CoTaskMemFree(pidl);
    }
    wcopy(g_status,validpaths()?L"READY TO PLAY":L"SELECT GAME FILES IN SETTINGS TO BEGIN",200);
    InvalidateRect(g_window,0,FALSE);
}

static void setStatus(const wchar_t *s){wcopy(g_status,s,200);InvalidateRect(g_window,0,FALSE);}
static void launchGame(void){
    if(!validpaths()){
      g_settingsOpen=1;setStatus(L"CHOOSE GAME FILES TO CONTINUE");
      MessageBoxW(g_window,L"Choose your installed game executable and extracted game data in Settings.",
                  L"Find War for Cybertron",MB_OK);return;
    }
    if(!g_fsr&&g_render==2){
        const wchar_t *notice =
            L"1440p performance note\n\n"
            L"The main menu may run slowly for approximately 30-50 seconds "
            L"after starting the game or returning from Campaign.\n\n"
            L"In our testing, normal gameplay performance was much better. "
            L"Results may vary by PC and game scene.\n\n"
            L"Continue launching at 1440p?";
        if(MessageBoxW(g_window,notice,L"War for Cybertron - 1440p Notice",
                       MB_YESNO|0x40u)!=IDYES)return;
    }
    if(g_fsr&&!fsrready()){
       MessageBoxW(g_window,L"FSR requires the verified FidelityFX runtime beside this launcher in the FSR folder.\n\nRun Install-WFC-FSR-Launcher.ps1 once, then try again.",
           L"FSR installation required",MB_OK|MB_ICONERROR);return;
    }
    savestate();
    const wchar_t *activeGame=g_fsr?g_fsrGame:g_game;
    wchar_t working[MAXPATH];wcopy(working,g_game,MAXPATH);parentdir(working);
    /* Use the original project working directory even for staged FSR:
       this matches the already verified experimental launch procedure. */
    /* Prefer game project root instead of its build folder, matching the working CLI setup. */
    int n=wlen(working);const wchar_t suffix[]=L"\\out\\build\\win-amd64-release";
    int sn=wlen(suffix),same=n>=sn;
    if(same){for(int i=0;i<sn;i++){if(working[n-sn+i]!=suffix[i]){same=0;break;}}}
    if(same)working[n-sn]=0;
    wchar_t command[MAXPATH*2+120];wcopy(command,L"\"",MAXPATH*2+120);
    wcat(command,activeGame,MAXPATH*2+120);wcat(command,L"\" --game_data_root=\"",MAXPATH*2+120);
    wcat(command,g_data,MAXPATH*2+120);wcat(command,L"\" --gpu_plugin=xenos",MAXPATH*2+120);
    /* Exact proven-good flags from the user's manual 1440p launch.
       We set each axis explicitly; legacy --draw_resolution_scale was ineffective.
       Both 1080p supersampled and 1440p use 2x internal rendering. */
    static const wchar_t *scaleArgs[]={
       L" --resolution_scale=1 --draw_resolution_scale_x=1 --draw_resolution_scale_y=1 --vsync=false",
       L" --resolution_scale=2 --draw_resolution_scale_x=2 --draw_resolution_scale_y=2 --vsync=false",
       L" --resolution_scale=2 --draw_resolution_scale_x=2 --draw_resolution_scale_y=2 --vsync=false"
    };
    if(g_fsr){
        /* FSR spatial effect: fixed genuine 720p guest render target,
           higher-resolution host output. Never pass native 2x scales too. */
        wcat(command,scaleArgs[0],MAXPATH*2+120);
        wcat(command,L" --present_effect=fsr --fullscreen=false --resolution=",MAXPATH*2+120);
        wappendnum(command,(unsigned)g_fsrOutW[g_fsrOutput],MAXPATH*2+120);
        wcat(command,L"x",MAXPATH*2+120);
        wappendnum(command,(unsigned)g_fsrOutH[g_fsrOutput],MAXPATH*2+120);
    }else{
        wcat(command,scaleArgs[g_render],MAXPATH*2+120);
    }
    /* Real FidelityFX CAS strength. Native uses CAS effect when enabled;
       FSR remains the upscaler and gains an optional CAS post-pass in
       the matched renderer build. 0% retains the previous FSR path. */
    if(g_sharp>0){
        if(!g_fsr)wcat(command,L" --present_effect=cas",MAXPATH*2+120);
        wcat(command,L" --present_cas_additional_sharpness=",MAXPATH*2+120);
        wchar_t frac[5]={L'0',L'.',L'0',L'0',0};
        if(g_sharp==100)frac[0]=L'1';
        else{frac[2]=(wchar_t)(L'0'+g_sharp/10);frac[3]=(wchar_t)(L'0'+g_sharp%10);}
        wcat(command,frac,MAXPATH*2+120);
    }
    struct STARTUPINFOW si={0};struct PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
    if(!CreateProcessW(activeGame,command,0,0,FALSE,0,0,working,&si,&pi)){
      setStatus(L"COULD NOT START THE GAME — CHECK SETTINGS");
      MessageBoxW(g_window,L"Couldn't launch Cybertron. Check Settings for the game path and extracted data folder.",
         L"War for Cybertron",MB_ICONERROR);return;
    }
    g_gamePid=pi.dwProcessId;
    g_gameProcess=pi.hProcess;CloseHandle(pi.hThread);
    g_exitMode=1;g_gameTick=0;
    stopmusic();KillTimer(g_window,TIMER_MUSIC);
    ShowWindow(g_window,SW_HIDE);
    SetTimer(g_window,TIMER_GAME,500,0);
}
struct FIND_WINDOW {DWORD pid;HWND hwnd;};
static BOOL WINAPI gameWindowCallback(HWND hwnd,LPARAM lp){
    struct FIND_WINDOW *target=(struct FIND_WINDOW*)lp;
    DWORD pid=0;GetWindowThreadProcessId(hwnd,&pid);
    if(pid==target->pid&&IsWindowVisible(hwnd)){
        struct RECT rc={0};GetWindowRect(hwnd,&rc);
        if((rc.right-rc.left)>300 && (rc.bottom-rc.top)>200){target->hwnd=hwnd;return FALSE;}
    }
    return TRUE;
}
static void adjustGameWindow(HWND window){
    if(!window || !IsWindow(window))return;
    HMONITOR monitor=MonitorFromWindow(window,MONITOR_DEFAULTTONEAREST);
    struct MONITORINFO info={0};info.cbSize=sizeof(info);
    if(!monitor||!GetMonitorInfoW(monitor,&info))return;
    struct RECT bounds=info.rcMonitor;
    intptr_t style=GetWindowLongPtrW(window,GWL_STYLE);
    if(g_mode==0){
        style &= ~((intptr_t)WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX);
        style |= (intptr_t)WS_POPUP;
        SetWindowLongPtrW(window,GWL_STYLE,style);
        SetWindowPos(window,0,bounds.left,bounds.top,bounds.right-bounds.left,bounds.bottom-bounds.top,
           SWP_NOZORDER|SWP_NOACTIVATE|SWP_FRAMECHANGED|SWP_SHOWWINDOW);
    }else{
        style &= ~(intptr_t)WS_POPUP;
        style |= (intptr_t)(WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|WS_MINIMIZEBOX);
        SetWindowLongPtrW(window,GWL_STYLE,style);
        int w=g_fsr?g_fsrOutW[g_fsrOutput]:g_resW[g_resolution],h=g_fsr?g_fsrOutH[g_fsrOutput]:g_resH[g_resolution];
        /* An automatic window size tracks the selected rendering preset.
           The 1080p setting is 2x supersampled, downscaled to this window. */
        if(w==0||h==0){
            if(g_render==0){w=1280;h=720;}
            else if(g_render==1){w=1920;h=1080;}
            else {w=2560;h=1440;}
            /* On displays smaller than the requested game window, fit it. */
            if(w>bounds.right-bounds.left || h>bounds.bottom-bounds.top){
                w=bounds.right-bounds.left-48;h=w*9/16;
                if(h>bounds.bottom-bounds.top-80){h=bounds.bottom-bounds.top-80;w=h*16/9;}
            }
        }
        struct RECT rc={0,0,w,h};AdjustWindowRectEx(&rc,(DWORD)style,FALSE,0);
        int outerw=rc.right-rc.left,outerh=rc.bottom-rc.top;
        int x=bounds.left+((bounds.right-bounds.left)-outerw)/2;
        int y=bounds.top+((bounds.bottom-bounds.top)-outerh)/2;
        SetWindowPos(window,0,x,y,outerw,outerh,SWP_NOZORDER|SWP_NOACTIVATE|SWP_FRAMECHANGED|SWP_SHOWWINDOW);
    }
}
static void monitorGame(void){
    g_gameTick++;
    if(!g_gameProcess || WaitForSingleObject(g_gameProcess,0)==0){
        DestroyWindow(g_window);return;
    }
    struct FIND_WINDOW found={0};found.pid=(DWORD)g_gamePid;
    EnumWindows(gameWindowCallback,(LPARAM)&found);
    if(found.hwnd){adjustGameWindow(found.hwnd);g_gameWindowFound=1;}
    /* Native helper has a bounded life; it is *this same EXE* and never PowerShell. */
    if(g_gameTick>=180 || (g_gameWindowFound&&g_gameTick>=60)){
        DestroyWindow(g_window);
    }
}
static LRESULT WINAPI MainWndProc(HWND window,UINT msg,WPARAM wp,LPARAM lp){
  switch(msg){
    case WM_PAINT:paint(window);return 0;
    case WM_ERASEBKGND:return 1;
    case WM_NCHITTEST:{
        LRESULT hit=DefWindowProcW(window,msg,wp,lp);
        if(hit!=HTCLIENT)return hit;
        struct POINT p={(short)(lp&0xFFFF),(short)((lp>>16)&0xFFFF)};
        ScreenToClient(window,&p);
        struct RECT r;GetClientRect(window,&r);int w=r.right-r.left,h=r.bottom-r.top;
        if(w>0&&h>0){int vx=p.x*1600/w,vy=p.y*900/h;
            if(vy>=0&&vy<30&&which(vx,vy)==0)return HTCAPTION;
        }
        return HTCLIENT;
    }
    case WM_MOUSEMOVE:{
        if(g_sharpDragging){if(wp&1u)updateCasFromMouse(lp);else{g_sharpDragging=0;savestate();}}
        int hover=posHit(lp);if(g_hover!=hover){g_hover=hover;InvalidateRect(window,0,FALSE);}return 0;}
    case WM_LBUTTONUP:{if(g_sharpDragging){updateCasFromMouse(lp);g_sharpDragging=0;savestate();InvalidateRect(window,0,FALSE);}return 0;}
    case WM_LBUTTONDOWN:{int hit=posHit(lp);
        if(hit==1){ShowWindow(window,SW_MINIMIZE);return 0;}
        if(hit==2){DestroyWindow(window);return 0;}
        if(hit==3){MessageBoxW(window,L"Transformers: War for Cybertron — Community PC Launcher\n\nOriginal artwork and soundtrack supplied by the community.\nUses your existing Windows game installation.",L"About the launcher",MB_OK);return 0;}
        if(hit==11){g_settingsOpen=!g_settingsOpen;InvalidateRect(window,0,FALSE);return 0;}
        if(hit==14){
            g_fsr=!g_fsr;
            if(g_fsr){selectFsrOutput(g_fsrOutput);}
            savestate();InvalidateRect(window,0,FALSE);return 0;
        }
        if(hit==13){g_sharpDragging=1;updateCasFromMouse(lp);savestate();return 0;}
        if(hit==4||hit==5||hit==12||hit==15){choosemenu(window,hit);return 0;}
        if(hit==6){pickGame();return 0;}
        if(hit==7){pickData();return 0;}
        if(hit==8){launchGame();return 0;}
        if(hit==9){g_resolution=0;g_render=0;g_mode=0;g_sharp=0;g_fsr=0;g_fsrOutput=1;savestate();setStatus(L"SETTINGS RESET");return 0;}
        if(hit==10){savestate();setStatus(L"SETTINGS SAVED");return 0;}
        return 0;
    }
    case WM_KEYDOWN:if(wp==VK_ESCAPE){if(g_settingsOpen){g_settingsOpen=0;InvalidateRect(window,0,FALSE);}else DestroyWindow(window);}else if(wp==VK_RETURN&&!g_settingsOpen)launchGame();return 0;
    case WM_SETCURSOR:{struct POINT p;if(GetCursorPos(&p)){ScreenToClient(window,&p);struct RECT r;GetClientRect(window,&r);if(which(p.x*1600/(r.right?r.right:1),p.y*900/(r.bottom?r.bottom:1))){SetCursor(LoadCursorW(0,(LPCWSTR)32649));return TRUE;}}return DefWindowProcW(window,msg,wp,lp);}
    case WM_TIMER:if(wp==TIMER_MUSIC)musicTick();else if(wp==TIMER_GAME)monitorGame();return 0;
    case WM_DESTROY:stopmusic();KillTimer(window,TIMER_GAME);KillTimer(window,TIMER_MUSIC);
         if(g_gameProcess)CloseHandle(g_gameProcess);
         if(g_backBmp)DeleteObject(g_backBmp);
         if(g_fontSmall)DeleteObject(g_fontSmall);
         if(g_fontMedium)DeleteObject(g_fontMedium);
         if(g_fontLarge)DeleteObject(g_fontLarge);
         if(g_fontTitle)DeleteObject(g_fontTitle);
         if(g_fontPlay)DeleteObject(g_fontPlay);
         PostQuitMessage(0);return 0;
  }
  return DefWindowProcW(window,msg,wp,lp);
}

void LauncherMain(void){
    g_instance=GetModuleHandleW(0);
    SetProcessDPIAware();initpaths();
    g_screenW=GetSystemMetrics(SM_CXSCREEN);g_screenH=GetSystemMetrics(SM_CYSCREEN);
    if(g_screenW<640||g_screenH<480){g_screenW=1600;g_screenH=900;}
    if(g_fsr&&g_mode==0&&(g_fsrOutW[g_fsrOutput]!=g_screenW||g_fsrOutH[g_fsrOutput]!=g_screenH))g_mode=1;
    g_fontSmall=CreateFontW(-17,0,0,0,500,0,0,0,1,0,0,5,0,L"Segoe UI");
    g_fontMedium=CreateFontW(-21,0,0,0,600,0,0,0,1,0,0,5,0,L"Segoe UI");
    g_fontLarge=CreateFontW(-27,0,0,0,700,0,0,0,1,0,0,5,0,L"Bahnschrift");
    g_fontTitle=CreateFontW(-33,0,0,0,800,0,0,0,1,0,0,5,0,L"Bahnschrift");
    g_fontPlay=CreateFontW(-42,0,0,0,800,0,0,0,1,0,0,5,0,L"Bahnschrift");
    g_backBmp=(HBITMAP)LoadImageW(0,g_image,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
    if(!g_backBmp){MessageBoxW(0,L"Missing Assets\\wfc_artwork.bmp. Extract the complete launcher ZIP.",
           L"War for Cybertron Launcher v1.0",MB_ICONERROR);ExitProcess(1);}
    struct WNDCLASSEXW wc={0};wc.cbSize=sizeof(wc);wc.style=CS_HREDRAW|CS_VREDRAW;wc.lpfnWndProc=MainWndProc;
    wc.hInstance=g_instance;wc.lpszClassName=L"WarForCybertronNativeLauncher";
    wc.hIcon=LoadIconW(g_instance,(LPCWSTR)1);wc.hIconSm=wc.hIcon;wc.hCursor=LoadCursorW(0,(LPCWSTR)32512);
    if(!RegisterClassExW(&wc)){MessageBoxW(0,L"Couldn't initialize the launcher window.",L"Cybertron",MB_ICONERROR);ExitProcess(2);}
    /* Windowed launcher, matching RB2 reference. Never occupy the entire display. */
    int launcherW=1520,launcherH=855;
    if(launcherW>g_screenW-100)launcherW=g_screenW-100;
    if(launcherH>g_screenH-100)launcherH=g_screenH-100;
    if(launcherW<700)launcherW=g_screenW*4/5;
    if(launcherH<430)launcherH=g_screenH*4/5;
    /* Keep the same 16:9 logical scene when fitting smaller screens. */
    if(launcherW*900>launcherH*1600)launcherW=launcherH*1600/900;
    else launcherH=launcherW*900/1600;
    int launcherX=(g_screenW-launcherW)/2,launcherY=(g_screenH-launcherH)/2;
    g_window=CreateWindowExW(0,wc.lpszClassName,L"Transformers: War for Cybertron",WS_POPUP|WS_VISIBLE,
       launcherX,launcherY,launcherW,launcherH,0,0,g_instance,0);
    if(!g_window){MessageBoxW(0,L"Couldn't create the launcher window.",L"Cybertron",MB_ICONERROR);ExitProcess(3);}
    ShowWindow(g_window,SW_SHOW);UpdateWindow(g_window);
    startmusic();
    struct MSG msg;
    while(GetMessageW(&msg,0,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    ExitProcess(0);
}
