.intel_syntax noprefix
.text
.globl __chkstk
__chkstk:
    push rcx
    mov rcx, rsp
    add rcx, 16
    mov r11, rax
    cmp r11, 4096
    jb .tail
.loop:
    sub rcx, 4096
    test byte ptr [rcx], 0
    sub r11, 4096
    cmp r11, 4096
    jae .loop
.tail:
    sub rcx, r11
    test byte ptr [rcx], 0
    pop rcx
    ret
