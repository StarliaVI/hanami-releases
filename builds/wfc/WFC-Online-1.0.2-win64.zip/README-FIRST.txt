WAR FOR CYBERTRON - COMMUNITY ONLINE EDITION
============================================
Play Transformers: War for Cybertron online again, on PC, with friends.
No VPN, no IP addresses, no port forwarding.

WHAT YOU NEED
  * Your own copy of Transformers: War for Cybertron for Xbox 360, as a disc
    image (.iso). The game itself is NOT included - the installer builds it
    from your disc.
  * Windows 10 or 11 (64-bit), a DirectX 12 graphics card, 16 GB RAM recommended.
  * About 25 GB free disk space during install (about 10 GB afterwards).
  * An internet connection.

INSTALL (one time)
  1. Extract this whole ZIP to a folder with a simple path, for example:
        D:\Games\WFC-Online
  2. Double-click INSTALL.cmd
       - If Windows says "Windows protected your PC": click "More info",
         then "Run anyway". (The installer is not code-signed.)
  3. Pick your War for Cybertron .iso when asked.
  4. Say Y when it offers to install the free build tools. Windows will ask
     you to allow each one - click Yes.
  5. Wait while it builds the game from your disc. Typically 5-15 minutes on a
     modern PC, up to an hour on an older one. You can keep using your PC.
  6. Type your online name (gamertag) when asked - see
     HOW-TO-SET-YOUR-ONLINE-NAME.txt.
  7. Done! Open WarForCybertron-Launcher.exe (or the desktop shortcut) and press PLAY.

PLAYING ONLINE
  * Main menu -> Xbox LIVE Multiplayer.
  * With 2 players: Escalation ("Find a Public Game") or co-op Campaign work
    great. Versus matchmaking (e.g. Team Deathmatch) waits for 4 players.
  * Your account is created automatically the first time you start the game.

IF SOMETHING GOES WRONG
  * Just run INSTALL.cmd again - finished steps are skipped and it continues
    where it stopped.
  * install.log in this folder has the details; send it to whoever gave you
    this package.
  * "This disc is a different version": the online edition was made for one
    specific version of the game; other regions/versions may not work.

THIS IS AN EXPERIMENTAL COMMUNITY TEST BUILD
  Verified: accounts, finding and joining games, Escalation and co-op lobbies
  over the internet. Not yet verified: every mode/map, 3+ players, private
  matches/invites, stats/leaderboards, reconnecting after a disconnect.

WHAT THIS PACKAGE CONTAINS
  INSTALL.cmd + Install-WFC-Online.ps1   the installer (plain text, readable)
  installer\                             disc extractor, project build files,
                                         ReXGlue SDK (BSD licence, see LICENSE-ReXGlue.txt)
  FSR\                                   online runtime, FSR/CAS graphics DLLs
  WarForCybertron-Launcher.exe, Source\  community launcher (FSR/CAS options)
  NOT included: the game, game music/artwork, anyone's account keys.

Transformers and War for Cybertron are trademarks of their respective owners.
Unofficial community project, not affiliated with or endorsed by them.
