﻿<#
  WAR FOR CYBERTRON - COMMUNITY ONLINE EDITION : INSTALLER
  Run INSTALL.cmd. Everything happens inside this folder.

    1. You pick YOUR OWN War for Cybertron Xbox 360 disc image (.iso).
    2. The game files are extracted into GameData\ and checked.
    3. Missing build tools are installed with winget (Windows asks you to allow each one).
    4. The game is recompiled on THIS PC from your own disc (this takes a while).
    5. Online settings and your gamertag are set up. Then you just open the launcher.

  Re-running is safe: finished steps are skipped.
#>
[CmdletBinding()]
param(
  [string]$Iso,          # path to your disc image (or to default.xex of an extracted game)
  [string]$Gamertag,
  [string]$Claim,        # only for a reserved gamertag (given privately by the server owner)
  [switch]$Yes,          # answer yes to all questions (tool installs, cleanup)
  [switch]$Rebuild,      # rebuild the game even if it is already built
  [switch]$AnyVersion,   # allow a disc version other than the tested one (not recommended)
  [switch]$NoShortcut    # don't offer a desktop shortcut
)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$Inst = Join-Path $Root 'installer'
$GameData = Join-Path $Root 'GameData'
$Build = Join-Path $Root 'build'
$Fsr = Join-Path $Root 'FSR'
$Log = Join-Path $Root 'install.log'
$ExpectedXex = '107314b11111cef557b9bcee243b0a865c964f59cde99030c152265033934b22'
$Server = '132.145.71.71'
"=== WFC Online install $(Get-Date)" | Out-File $Log -Encoding utf8

function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c; $t | Out-File $Log -Append -Encoding utf8 }
function Step([string]$t) { Say "`n=== $t ===" 'Cyan' }
function Fail([string]$t) { Say "`nINSTALL STOPPED: $t" 'Red'; Say "Details are in install.log. You can run INSTALL.cmd again after fixing this." 'Yellow'; exit 1 }
function Confirm([string]$q) {
  if ($Yes) { return $true }
  while ($true) { $a = (Read-Host "$q [Y/N]").Trim().ToUpper(); if ($a -eq 'Y') { return $true }; if ($a -eq 'N') { return $false } }
}
function Sha([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() }
function Run([string]$exe, [string[]]$a, [string]$label) {
  $ErrorActionPreference = 'Continue'
  & $exe @a 2>&1 | ForEach-Object {
    $line = "$_"; $line | Out-File $Log -Append -Encoding utf8
    if ($line -match '^\[(\d+)/(\d+)\]') {
      $pct = [int](100 * [int]$Matches[1] / [int]$Matches[2])
      Write-Progress -Activity $label -Status "$($Matches[1]) of $($Matches[2]) steps" -PercentComplete $pct
    } elseif ($line -match 'phase\s+default\.xex: (\w+)') {
      Write-Progress -Activity $label -Status "Recompiling: $($Matches[1])"
    }
  }
  $code = $LASTEXITCODE
  Write-Progress -Activity $label -Completed
  return $code
}

Write-Host "`n  WAR FOR CYBERTRON - COMMUNITY ONLINE EDITION" -ForegroundColor White
Write-Host "  Installer  (all files stay in: $Root)`n" -ForegroundColor DarkGray
if ($Root -match '[^\x20-\x7E]') { Fail 'Please move this folder to a path with plain English letters only (e.g. D:\Games\WFC-Online).' }
if (Get-Process -Name warforcybertron -ErrorAction SilentlyContinue) { Fail 'Close War for Cybertron first.' }
foreach ($f in 'XisoExtract.cs', 'rexglue-sdk-win-amd64.zip', 'project\warforcybertron_manifest.toml') {
  if (-not (Test-Path -LiteralPath (Join-Path $Inst $f))) { Fail "installer\$f is missing - extract the WHOLE zip first." }
}
# Keep the PC responsive while compiling (child processes inherit this).
try { [Diagnostics.Process]::GetCurrentProcess().PriorityClass = 'BelowNormal' } catch {}

# ----------------------------------------------------------------------------------- 1. game files
Step '1/5  Your game disc'
$xex = Join-Path $GameData 'default.xex'
if ((Test-Path -LiteralPath $xex) -and (Test-Path -LiteralPath (Join-Path $GameData 'TransGame'))) {
  Say 'Game files are already extracted in GameData\ - skipping.' 'Green'
} else {
  if (-not $Iso) {
    Say 'Select YOUR War for Cybertron (Xbox 360) disc image (.iso).'
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'Select your Transformers: War for Cybertron Xbox 360 disc image'
    $dlg.Filter = 'Xbox 360 disc image (*.iso)|*.iso|Extracted game (default.xex)|default.xex|All files (*.*)|*.*'
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Fail 'No disc image selected.' }
    $Iso = $dlg.FileName
  }
  $Iso = $Iso.Trim('"', ' ')
  if (-not (Test-Path -LiteralPath $Iso -PathType Leaf)) { Fail "File not found: $Iso" }
  if ([IO.Path]::GetFileName($Iso) -ieq 'default.xex') {
    # Already-extracted game folder: copy it in.
    $srcDir = Split-Path -Parent $Iso
    if (-not (Test-Path -LiteralPath (Join-Path $srcDir 'TransGame'))) { Fail 'That folder does not contain TransGame - pick the extracted game folder''s default.xex.' }
    Say "Copying extracted game from $srcDir ..."
    & robocopy $srcDir $GameData /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { Fail "Copying the game files failed (robocopy code $LASTEXITCODE)." }
  } else {
    Add-Type -Path (Join-Path $Inst 'XisoExtract.cs')
    try { $files = [XisoExtract]::List($Iso) } catch { Fail "This doesn't look like an Xbox 360 game disc image: $($_.Exception.InnerException.Message)" }
    $names = $files | ForEach-Object { $_.Key }
    if (($names -notcontains 'default.xex') -or -not ($names | Where-Object { $_ -like 'TransGame\*' })) {
      Fail 'That disc image is not Transformers: War for Cybertron (no default.xex / TransGame).'
    }
    $total = ($files | Measure-Object -Property Value -Sum).Sum
    $drive = (Get-Item -LiteralPath $Root).PSDrive
    if ($drive -and $drive.Free -lt ($total + 20GB)) {
      Fail ("Not enough free space on {0}: need about {1:N0} GB (game + build), have {2:N0} GB." -f $drive.Name, (($total + 20GB) / 1GB), ($drive.Free / 1GB))
    }
    Say ("Extracting {0:N1} GB from your disc image..." -f ($total / 1GB))
    $tmp = "$GameData.partial"
    if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
    $cb = [XisoExtract+Progress] {
      param($done, $all, $file)
      try {
        if ($all -gt 0) {
          $st = if ([string]::IsNullOrEmpty($file)) { 'working...' } else { [string]$file }
          Write-Progress -Activity 'Extracting game files' -Status $st -PercentComplete ([Math]::Min(100, [int](100 * $done / $all)))
        }
      } catch { }   # progress display must never stop the extraction
    }
    try { [void][XisoExtract]::Extract($Iso, $tmp, $cb) } catch { Fail "Extraction failed: $($_.Exception.InnerException.Message)" }
    Write-Progress -Activity 'Extracting game files' -Completed
    Rename-Item -LiteralPath $tmp -NewName (Split-Path -Leaf $GameData)
  }
}
$xexSha = Sha $xex
if ($xexSha -eq $ExpectedXex) { Say 'Disc version check: OK (matches the tested version).' 'Green' }
elseif ($AnyVersion) { Say "Disc version differs from the tested one ($xexSha) - continuing because -AnyVersion was given." 'Yellow' }
else {
  Fail ("This disc is a different version/region of the game than the one the online edition was made for.`n" +
        "  expected default.xex SHA-256: $ExpectedXex`n  yours:                        $xexSha`n" +
        "  (Advanced: run INSTALL.cmd -AnyVersion to try anyway.)")
}

# ----------------------------------------------------------------------------------- 2. tools
Step '2/5  Build tools'
$exeDir = Join-Path $Build 'out\build\win-amd64-release'
$builtExe = Join-Path $exeDir 'warforcybertron.exe'
$needBuild = $Rebuild -or -not (Test-Path -LiteralPath (Join-Path $Fsr 'warforcybertron.exe'))
function Find-Tools {
  $t = @{}
  $t.LLVM = @("$env:ProgramFiles\LLVM\bin", "${env:ProgramFiles(x86)}\LLVM\bin") | Where-Object { Test-Path (Join-Path $_ 'clang++.exe') } | Select-Object -First 1
  $c = Get-Command cmake.exe -ErrorAction SilentlyContinue
  $t.CMake = if ($c) { $c.Source } elseif (Test-Path "$env:ProgramFiles\CMake\bin\cmake.exe") { "$env:ProgramFiles\CMake\bin\cmake.exe" } else { $null }
  $n = Get-Command ninja.exe -ErrorAction SilentlyContinue
  $t.Ninja = if ($n) { $n.Source } else {
    Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet" -Recurse -Filter ninja.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName }
  $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
  $t.MSVC = if (Test-Path $vswhere) { & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath } else { $null }
  $t.WinSDK = Get-ChildItem "${env:ProgramFiles(x86)}\Windows Kits\10\Lib\*\um\x64\kernel32.lib" -ErrorAction SilentlyContinue | Select-Object -First 1
  return $t
}
if (-not $needBuild) {
  Say 'Game is already built - skipping tools (use -Rebuild to build again).' 'Green'
} else {
  $tools = Find-Tools
  $missing = @()
  if (-not $tools.CMake) { $missing += @{ Name = 'CMake'; Id = 'Kitware.CMake'; Extra = @() } }
  if (-not $tools.Ninja) { $missing += @{ Name = 'Ninja'; Id = 'Ninja-build.Ninja'; Extra = @() } }
  if (-not $tools.LLVM) { $missing += @{ Name = 'LLVM / Clang compiler'; Id = 'LLVM.LLVM'; Extra = @() } }
  if (-not $tools.MSVC -or -not $tools.WinSDK) {
    $missing += @{ Name = 'Visual Studio Build Tools (C++ + Windows SDK)'; Id = 'Microsoft.VisualStudio.2022.BuildTools'
                   Extra = @('--override', '--passive --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended') }
  }
  if ($missing.Count -eq 0) { Say 'All build tools found.' 'Green' }
  else {
    Say 'These free build tools are needed to compile the game on this PC:'
    $missing | ForEach-Object { Say "   - $($_.Name)" 'White' }
    Say 'They are installed with winget (Microsoft''s package manager). Windows will ask you to allow each one.'
    if (-not (Confirm 'Install them now?')) { Fail 'Build tools are required. Run INSTALL.cmd again when you are ready.' }
    if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
      Fail 'winget is not available. Install "App Installer" from the Microsoft Store, then run INSTALL.cmd again.'
    }
    foreach ($m in $missing) {
      Say "Installing $($m.Name)... (this can take several minutes)"
      $a = @('install', '--id', $m.Id, '-e', '--accept-package-agreements', '--accept-source-agreements', '--silent') + $m.Extra
      $code = Run 'winget.exe' $a "Installing $($m.Name)"
      if ($code -ne 0 -and $code -ne -1978335189) {  # -1978335189 = already installed
        Say "winget returned code $code for $($m.Name)." 'Yellow'
      }
    }
    $tools = Find-Tools
    $still = @()
    if (-not $tools.CMake) { $still += 'CMake' }; if (-not $tools.Ninja) { $still += 'Ninja' }
    if (-not $tools.LLVM) { $still += 'LLVM' }; if (-not $tools.MSVC -or -not $tools.WinSDK) { $still += 'Visual Studio Build Tools' }
    if ($still.Count) { Fail "Still missing after install: $($still -join ', '). A restart of Windows sometimes helps; then run INSTALL.cmd again." }
    Say 'Build tools installed.' 'Green'
  }
}

# ----------------------------------------------------------------------------------- 3. build
Step '3/5  Building the game from your disc'
if (-not $needBuild) { Say 'Already built - skipping.' 'Green' }
else {
  $env:PATH = "$($tools.LLVM);$(Split-Path $tools.Ninja);$(Split-Path $tools.CMake);$env:PATH"
  $sdkDir = Join-Path $Build 'sdk'
  $findCfg = { Get-ChildItem $sdkDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -in 'rexglueConfig.cmake', 'rexglue-config.cmake' } | Select-Object -First 1 }
  if (-not (& $findCfg)) {
    Say 'Unpacking the ReXGlue SDK...'
    New-Item -ItemType Directory -Force -Path $sdkDir | Out-Null
    Expand-Archive -LiteralPath (Join-Path $Inst 'rexglue-sdk-win-amd64.zip') -DestinationPath $sdkDir -Force
  }
  $cfg = & $findCfg
  if (-not $cfg) { Fail 'ReXGlue SDK package is damaged (no rexglue-config.cmake).' }
  $sdkRoot = $cfg.Directory.Parent.Parent.Parent.FullName         # <sdk>\lib\cmake\rexglue -> <sdk>
  $rexglue = Join-Path $sdkRoot 'bin\rexglue.exe'
  $proj = $Build
  foreach ($d in 'src', 'generated') { New-Item -ItemType Directory -Force -Path (Join-Path $proj $d) | Out-Null }
  Copy-Item (Join-Path $Inst 'project\*') $proj -Recurse -Force
  $m = Get-Content -LiteralPath (Join-Path $proj 'warforcybertron_manifest.toml') -Raw
  $gd = $GameData -replace '\\', '/'
  $m = $m -replace 'game_root = ".*?"', "game_root = `"$gd`"" -replace 'file_path = ".*?default\.xex"', "file_path = `"$gd/default.xex`""
  [IO.File]::WriteAllText((Join-Path $proj 'warforcybertron_manifest.toml'), $m)
  Push-Location $proj
  try {
    Say 'Recompiling the game code from your default.xex (a few minutes)...'
    if ((Run $rexglue @('codegen', (Join-Path $proj 'warforcybertron_manifest.toml')) 'Recompiling') -ne 0) { Fail 'Recompiling the game code failed.' }
    Say 'Configuring...'
    if ((Run $tools.CMake @('--preset', 'win-amd64-release', "-DCMAKE_PREFIX_PATH=$sdkRoot",
          "-DCMAKE_CXX_COMPILER=$($tools.LLVM)\clang++.exe", "-DCMAKE_MAKE_PROGRAM=$($tools.Ninja)") 'Configuring') -ne 0) { Fail 'Configuring the build failed.' }
    # Each compile job needs a lot of memory: one job per ~3 GB of RAM, at most one per CPU thread.
    $ramGB = [math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
    $jobs = [math]::Max(1, [math]::Min([Environment]::ProcessorCount, [math]::Floor($ramGB / 3)))
    Say "Compiling with $jobs parallel jobs ($ramGB GB RAM, $([Environment]::ProcessorCount) CPU threads)."
    Say 'This is the long part: typically 5-15 minutes, up to an hour on an older PC.' 'Yellow'
    Say 'You can keep using your PC; the build runs at low priority. Do not close this window.'
    $sw = [Diagnostics.Stopwatch]::StartNew()
    if ((Run $tools.CMake @('--build', 'out\build\win-amd64-release', '-j', "$jobs") 'Compiling War for Cybertron') -ne 0) {
      Fail 'Compiling failed (see install.log). If your PC ran out of memory, close other programs and run INSTALL.cmd again - it continues where it stopped.'
    }
    Say ("Build finished in {0:N0} minutes." -f $sw.Elapsed.TotalMinutes) 'Green'
  } finally { Pop-Location }
  if (-not (Test-Path -LiteralPath $builtExe)) { Fail 'Build finished but warforcybertron.exe was not produced.' }
  Copy-Item -LiteralPath $builtExe -Destination (Join-Path $Fsr 'warforcybertron.exe') -Force
}

# ----------------------------------------------------------------------------------- 4. online
Step '4/5  Online settings and your gamertag'
$ini = Join-Path $Fsr 'wfc_online.ini'
$account = Join-Path $Fsr 'wfc_account.ini'
$current = $null
if (Test-Path -LiteralPath $ini) {
  $mm = Select-String -LiteralPath $ini -Pattern '^gamertag=(.+)$' | Select-Object -First 1
  if ($mm) { $current = $mm.Matches[0].Groups[1].Value.Trim() }
  if (-not $Claim) {   # keep a claim code that is already set (re-running the installer must not drop it)
    $mc = Select-String -LiteralPath $ini -Pattern '^claim=(.+)$' | Select-Object -First 1
    if ($mc) { $Claim = $mc.Matches[0].Groups[1].Value.Trim() }
  }
}
if (-not $Gamertag) {
  if (Test-Path -LiteralPath $account) {
    Say "You already have an online account here. Press Enter to keep your gamertag$(if ($current) { " ($current)" }),"
    Say 'or type a new one to rename (your progress is kept; once per 24 hours).'
  } else {
    Say 'Choose your online gamertag - this is the name other players see.'
    Say 'Rules: letters, numbers and single spaces, must start with a letter, max 15 characters.'
    Say 'If someone already has it, the server adds a number (e.g. Name4821). See HOW-TO-SET-YOUR-ONLINE-NAME.txt.'
  }
  while ($true) {
    $Gamertag = (Read-Host 'Gamertag').Trim()
    if (-not $Gamertag -and (Test-Path -LiteralPath $account)) { $Gamertag = $current; break }
    if ($Gamertag -match '^[A-Za-z][A-Za-z0-9 ]{0,14}$' -and $Gamertag -notmatch '  ' -and -not $Gamertag.EndsWith(' ')) { break }
    Write-Host 'Not valid - letters/numbers/single spaces, start with a letter, max 15. Try again.' -ForegroundColor Yellow
  }
}
$lines = @('; WFC Online Edition - community server settings', 'enabled=1', "server=$Server", 'lobby_port=47300')
if ($Gamertag) { $lines += "gamertag=$Gamertag" }
if ($Claim) { $lines += "claim=$Claim" }
[IO.File]::WriteAllLines($ini, $lines, (New-Object Text.UTF8Encoding($false)))
$settings = Join-Path $Root 'settings.ini'
$values = [ordered]@{ Resolution = '0'; Mode = '0'; RenderPreset = '0'; FpsPreset = '1'; FsrEnabled = '1'; FsrOutput = '1'; CasSharpening = '0' }
if (Test-Path -LiteralPath $settings) {
  foreach ($l in Get-Content -LiteralPath $settings) { if ($l -match '^(\w+)=(.*)$' -and $Matches[1] -notin 'GameExe', 'GameData') { $values[$Matches[1]] = $Matches[2] } }
}
$values['GameExe'] = Join-Path $Fsr 'warforcybertron.exe'
$values['GameData'] = $GameData
[IO.File]::WriteAllLines($settings, (@('[Launcher]') + ($values.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" })), [Text.Encoding]::Unicode)
Say "Online: server $Server, gamertag '$Gamertag'." 'Green'

# ----------------------------------------------------------------------------------- 5. finish
Step '5/5  Finishing'
if ((Test-Path -LiteralPath (Join-Path $Build 'out')) -and (Test-Path -LiteralPath (Join-Path $Fsr 'warforcybertron.exe'))) {
  $sz = (Get-ChildItem -LiteralPath $Build -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB
  if (Confirm ("Delete the temporary build files ({0:N1} GB)? The game is already copied into FSR\." -f $sz)) {
    Remove-Item -LiteralPath $Build -Recurse -Force -ErrorAction SilentlyContinue
    Say 'Temporary build files removed.'
  }
}
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'War for Cybertron Online.lnk'
if (-not $NoShortcut -and -not (Test-Path -LiteralPath $lnk) -and (Confirm 'Create a desktop shortcut?')) {
  $ws = New-Object -ComObject WScript.Shell
  $s = $ws.CreateShortcut($lnk); $s.TargetPath = Join-Path $Root 'WarForCybertron-Launcher.exe'; $s.WorkingDirectory = $Root; $s.Save()
}
Say "`nALL DONE! Open WarForCybertron-Launcher.exe and press PLAY." 'Green'
Say 'Your online account is created the first time the game starts. Then choose Xbox LIVE Multiplayer.'
Say 'Keep FSR\wfc_account.ini private - it is your login. Never send it to anyone.'
if (-not $Yes -and (Confirm 'Start the launcher now?')) { Start-Process -FilePath (Join-Path $Root 'WarForCybertron-Launcher.exe') -WorkingDirectory $Root }
